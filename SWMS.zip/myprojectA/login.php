<?php
session_start();
include_once 'config/database.php';
include_once 'includes/functions.php';



// Prevent caching
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userId = sanitize($_POST['userId']);
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    
    // First check if it's admin login
    if ($userId === '000' && $username === 'admin@swms.com') {
        // Check admin credentials
        $stmt = $conn->prepare("SELECT * FROM admin WHERE id = ? AND username = ? AND password = ?");
        $stmt->bind_param("sss", $userId, $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $_SESSION['admin_id'] = $userId;
            $_SESSION['admin_username'] = $username;
            $_SESSION['user_type'] = 'admin';
            
            // Redirect to admin dashboard
            header('Location: admin.php');
            exit();
        }
        $stmt->close();
    }
    
    // If not admin or admin login failed, check user login
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ? AND username = ? AND password = ?");
    $stmt->bind_param("sss", $userId, $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        
        // Check if account is active
        if ($user['status'] == 'deactivated') {
            // Store message for contact admin form
            $_SESSION['deactivated_user'] = [
                'user_id' => $userId,
                'username' => $username,
                'email' => $user['email']
            ];
            
            // Redirect to contact admin form
            header('Location: contact_admin.php');
            exit();
        }
        
        // Set session variables for user
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['user_type'] = 'user';
        
        // Redirect to user dashboard
        header('Location: user_dashboard.php');
        exit();
    } else {
        // Invalid credentials for both admin and user
        echo '<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Login Failed</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link rel="stylesheet" href="css/style.css">
        </head>
        <body>
            <div class="container mt-5">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="card border-danger">
                            <div class="card-header bg-danger text-white">
                                <h4><i class="fas fa-exclamation-triangle"></i> Login Failed</h4>
                            </div>
                            <div class="card-body">
                                <div class="alert alert-danger">
                                    <h5><i class="fas fa-times-circle"></i> Invalid Credentials!</h5>
                                    <p>Please check your User ID, Username, and Password.</p>
                                </div>
                                <div class="mt-3">
                                    <a href="index.php?showLogin=true" class="btn btn-primary">
                                     <i class="fas fa-redo"></i> Try Again
                                    </a>
                                    <a href="index.php" class="btn btn-outline-secondary">
                                        <i class="fas fa-home"></i> Back to Home
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>';
    }
    
    $stmt->close();
    $conn->close();
    exit();
}

// If accessed directly, redirect to home
header('Location: index.php');
exit();
?>