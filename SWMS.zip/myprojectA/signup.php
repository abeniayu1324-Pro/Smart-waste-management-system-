<?php
include_once 'config/database.php';
include_once 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $fullname = sanitize($_POST['fullname']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !strpos($email, '@gmail.com')) {
        die(showStyledError('Please use a valid @gmail.com email address!'));
    }
    
    // Check if email already exists
    $checkEmail = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $result = $checkEmail->get_result();
    
    if ($result->num_rows > 0) {
        die(showStyledError('Email already registered! Please use a different email.'));
    }
    
    // Generate user ID
    $user_id = generateUserID();
    
    // Generate username
    $username = generateUsername($fullname);
    
    // Check if username exists
    $checkUsername = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $checkUsername->bind_param("s", $username);
    $checkUsername->execute();
    
    if ($checkUsername->get_result()->num_rows > 0) {
        // Add numbers if username exists
        $counter = 1;
        while (true) {
            $newUsername = str_replace(' ', '', $fullname) . $counter . '@swms.com';
            $checkUsername->bind_param("s", $newUsername);
            $checkUsername->execute();
            if ($checkUsername->get_result()->num_rows == 0) {
                $username = $newUsername;
                break;
            }
            $counter++;
        }
    }
    
    // Insert user into database
    $stmt = $conn->prepare("INSERT INTO users (user_id, username, fullname, email, password, status) VALUES (?, ?, ?, ?, ?, 'active')");
    $stmt->bind_param("sssss", $user_id, $username, $fullname, $email, $password);
    
    if ($stmt->execute()) {
        // Show success message with credentials
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Registration Successful</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
            <link rel="stylesheet" href="css/style.css">
            <style>
                body {
                    background: linear-gradient(135deg, #1b5e20, #2e7d32);
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px;
                }
                .success-container {
                    background: white;
                    border-radius: 15px;
                    padding: 40px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                    max-width: 600px;
                    width: 100%;
                }
                .credentials-box {
                    background: #f8f9fa;
                    border: 2px solid #2e7d32;
                    border-radius: 10px;
                    padding: 20px;
                    margin: 20px 0;
                }
                .copy-btn {
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                .copy-btn:hover {
                    background-color: #e9ecef;
                    transform: scale(1.05);
                }
                .login-redirect-btn {
                    background: linear-gradient(135deg, #2e7d32, #1b5e20);
                    color: white;
                    border: none;
                    padding: 12px 30px;
                    border-radius: 25px;
                    font-weight: 600;
                    transition: all 0.3s ease;
                    text-decoration: none;
                    display: inline-block;
                }
                .login-redirect-btn:hover {
                    background: linear-gradient(135deg, #1b5e20, #2e7d32);
                    color: white;
                    transform: translateY(-2px);
                    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
                }
            </style>
            <script>
                function copyToClipboard(text) {
                    navigator.clipboard.writeText(text).then(function() {
                        // Show copied notification
                        const notification = document.createElement('div');
                        notification.className = 'alert alert-success position-fixed';
                        notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 200px;';
                        notification.innerHTML = '<i class="fas fa-check"></i> Copied to clipboard!';
                        document.body.appendChild(notification);
                        
                        // Remove notification after 3 seconds
                        setTimeout(() => {
                            notification.remove();
                        }, 3000);
                    });
                }
            </script>
        </head>
        <body>
            <div class="success-container">
                <div class="text-center mb-4">
                    <i class="fas fa-check-circle fa-4x text-success"></i>
                    <h2 class="mt-3 text-success">Registration Successful!</h2>
                    <p class="text-muted">Your account has been created successfully. Please save your login credentials.</p>
                </div>
                
                <div class="credentials-box">
                    <h5 class="text-center mb-4"><i class="fas fa-key"></i> Your Login Details</h5>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">User ID</label>
                        <div class="input-group">
                            <span class="input-group-text bg-success text-white">
                                <i class="fas fa-id-card"></i>
                            </span>
                            <input type="text" class="form-control fw-bold text-success" value="<?php echo $user_id; ?>" readonly>
                            <button class="btn btn-outline-success copy-btn" onclick="copyToClipboard('<?php echo $user_id; ?>')">
                                <i class="fas fa-copy"></i> Copy
                            </button>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Username</label>
                        <div class="input-group">
                            <span class="input-group-text bg-success text-white">
                                <i class="fas fa-user"></i>
                            </span>
                            <input type="text" class="form-control fw-bold text-success" value="<?php echo $username; ?>" readonly>
                            <button class="btn btn-outline-success copy-btn" onclick="copyToClipboard('<?php echo $username; ?>')">
                                <i class="fas fa-copy"></i> Copy
                            </button>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Password</label>
                        <div class="input-group">
                            <span class="input-group-text bg-success text-white">
                                <i class="fas fa-lock"></i>
                            </span>
                            <input type="password" class="form-control fw-bold" value="<?php echo htmlspecialchars($password); ?>" readonly>
                           
                        </div>
                        <small class="text-muted">Keep your password secure and don't share it with anyone</small>
                    </div>
                </div>
                
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Important:</strong> Please save these credentials. You will need them to login to your account.
                </div>
                
                <div class="text-center mt-4">
                    <a href="index.php?showLogin=true" class="login-redirect-btn me-3">
                        <i class="fas fa-sign-in-alt me-2"></i> Go to Login
                    </a>
                    <a href="index.php" class="btn btn-outline-secondary">
                        <i class="fas fa-home me-2"></i> Back to Home
                    </a>
                </div>
            </div>
            
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        </body>
        </html>
        <?php
    } else {
        die(showStyledError('Registration failed: ' . $conn->error));
    }
    
    $stmt->close();
    $conn->close();
    exit();
}

// If accessed directly, redirect to home
header('Location: index.php');
exit();

// Function to show styled error popup
function showStyledError($message) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registration Error</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        <link rel="stylesheet" href="css/style.css">
        <style>
            body {
                background: linear-gradient(135deg, #f8d7da, #f5c6cb);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }
            .error-popup {
                background: white;
                border-radius: 15px;
                padding: 40px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                max-width: 500px;
                width: 100%;
                border-top: 5px solid #dc3545;
                animation: shake 0.5s ease-in-out;
            }
            @keyframes shake {
                0%, 100% { transform: translateX(0); }
                10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
                20%, 40%, 60%, 80% { transform: translateX(5px); }
            }
            .error-icon {
                font-size: 60px;
                color: #dc3545;
                margin-bottom: 20px;
            }
            .retry-btn {
                background: linear-gradient(135deg, #dc3545, #c82333);
                color: white;
                border: none;
                padding: 10px 25px;
                border-radius: 25px;
                font-weight: 600;
                transition: all 0.3s ease;
            }
            .retry-btn:hover {
                background: linear-gradient(135deg, #c82333, #dc3545);
                transform: translateY(-2px);
                box-shadow: 0 5px 15px rgba(220, 53, 69, 0.3);
            }
        </style>
        <script>
            function goBackToSignup() {
                window.history.back();
            }
            
            // Auto-redirect back after 8 seconds
            setTimeout(function() {
                goBackToSignup();
            }, 8000);
        </script>
    </head>
    <body>
        <div class="error-popup text-center">
            <div class="error-icon">
                <i class="fas fa-exclamation-circle"></i>
            </div>
            <h3 class="text-danger mb-3">Registration Error</h3>
            <div class="alert alert-danger">
                <i class="fas fa-times-circle"></i>
                <strong>Error:</strong> <?php echo $message; ?>
            </div>
            <p class="text-muted mb-4">Please check your information and try again.</p>
            
            <div class="d-grid gap-2">
                <button onclick="goBackToSignup()" class="retry-btn">
                    <i class="fas fa-redo me-2"></i> Try Again
                </button>
                <a href="index.php" class="btn btn-outline-secondary">
                    <i class="fas fa-home me-2"></i> Back to Home
                </a>
            </div>
            
            <div class="mt-4">
                <small class="text-muted">You will be redirected back to signup in <span id="countdown">8</span> seconds...</small>
            </div>
        </div>
        
        <script>
            // Auto-redirect countdown
            let countdown = 8;
            const countdownElement = document.getElementById('countdown');
            
            const countdownInterval = setInterval(function() {
                countdown--;
                countdownElement.textContent = countdown;
                
                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    goBackToSignup();
                }
            }, 1000);
        </script>
    </body>
    </html>
    <?php
    exit();
}
?>