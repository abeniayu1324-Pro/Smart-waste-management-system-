<?php
if (!isset($_SESSION)) {
    session_start();
}
include_once 'config/database.php';
include_once 'includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Handle form submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Use isset() checks to prevent warnings
    $phone = isset($_POST['phone']) ? sanitize($_POST['phone']) : '';
    $waste_type = isset($_POST['waste_type']) ? sanitize($_POST['waste_type']) : '';
    $address = isset($_POST['address']) ? sanitize($_POST['address']) : '';
    $home_number = isset($_POST['home_number']) ? sanitize($_POST['home_number']) : '';
    
    // Validate required fields
    if (empty($phone) || empty($waste_type) || empty($address) || empty($home_number)) {
        $message = showError('All fields are required!');
    } elseif (!preg_match('/^\d{4,5}$/', $home_number)) {
        $message = showError('Home number must be 4-5 digits!');
    } elseif (!preg_match('/^\+251\s?\d{9}$/', $phone)) {
        $message = showError('Please enter a valid Ethiopian phone number (format: +251 912345678)');
    } else {
        // Insert request
        $stmt = $conn->prepare("INSERT INTO requests (user_id, username, phone, waste_type, address, home_number) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $user_id, $username, $phone, $waste_type, $address, $home_number);
        
        if ($stmt->execute()) {
            $message = showSuccess('Waste collection request created successfully!');
            
            // Clear form fields after successful submission
            echo '<script>
                document.getElementById("phone").value = "";
                document.getElementById("waste_type").selectedIndex = 0;
                document.getElementById("address").selectedIndex = 0;
                document.getElementById("home_number").value = "";
            </script>';
        } else {
            $message = showError('Failed to create request: ' . $conn->error);
        }
        $stmt->close();
    }
}
?>
<div class="container">
    <h3 class="mb-4"><i class="fas fa-plus-circle text-success"></i> Create Waste Collection Request</h3>
    
    <?php echo $message; ?>
    
    <div class="card shadow">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0"><i class="fas fa-trash-alt"></i> Request Details</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="user_id" class="form-label">User ID </label>
                        <input type="text" class="form-control" id="user_id" value="<?php echo $user_id; ?>" readonly>
                        <small class="text-muted">Your registered User ID</small>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="username" class="form-label">Username </label>
                        <input type="text" class="form-control" id="username" value="<?php echo $username; ?>" readonly>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="phone" class="form-label">Phone Number</label>
                        <input type="tel" class="form-control" id="phone" name="phone" 
                               placeholder="+251 912345678" required>
                        <small class="text-muted">Format: +251 912345678</small>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="waste_type" class="form-label">Type of Waste</label>
                        <select class="form-select" id="waste_type" name="waste_type" required>
                            <option value="">Select waste type...</option>
                            <?php
                            $waste_types = getWasteTypes();
                            foreach ($waste_types as $type) {
                                echo '<option value="' . $type . '">' . $type . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-8 mb-3">
                        <label for="address" class="form-label">Address </label>
                        <select class="form-select" id="address" name="address" required>
                            <option value="">Select your location...</option>
                            <?php
                            $cities = getEthiopianCities();
                            foreach ($cities as $city) {
                                echo '<option value="' . $city . '">' . $city . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <label for="home_number" class="form-label">Home Number </label>
                        <input type="text" class="form-control" id="home_number" name="home_number" 
                               placeholder="e.g., 1234" required>
                        <small class="text-muted">4-5 digits only</small>
                    </div>
                </div>
                
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    Our team will contact you within 24 hours to schedule collection.
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="user_dashboard.php?tab=dashboard" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-paper-plane"></i> Submit Request
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Phone number formatting
document.getElementById('phone').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    
    if (value.length >= 9) {
        let formatted = '+251 ' + value.substring(value.length - 9);
        e.target.value = formatted;
    }
});

// Real-time validation for home number
document.getElementById('home_number').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    e.target.value = value.substring(0, 5); // Limit to 5 digits
    
    // Validate length
    if (value.length >= 4 && value.length <= 5) {
        e.target.classList.remove('is-invalid');
        e.target.classList.add('is-valid');
    } else {
        e.target.classList.remove('is-valid');
        e.target.classList.add('is-invalid');
    }
});

// Form validation before submission
document.querySelector('form').addEventListener('submit', function(e) {
    const phone = document.getElementById('phone').value;
    const homeNumber = document.getElementById('home_number').value;
    
    // Phone validation
    const phoneRegex = /^\+251\s?\d{9}$/;
    if (!phoneRegex.test(phone)) {
        e.preventDefault();
        alert('Please enter a valid Ethiopian phone number (format: +251 912345678)');
        return false;
    }
    
    // Home number validation
    const homeRegex = /^\d{4,5}$/;
    if (!homeRegex.test(homeNumber)) {
        e.preventDefault();
        alert('Home number must be 4-5 digits only!');
        return false;
    }
    
    return true;
});
</script>