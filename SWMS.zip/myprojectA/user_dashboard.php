<?php
include_once 'config/database.php';
include_once 'includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: index.php');
    exit();
}

// Get user details
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$fullname = $_SESSION['fullname'];

// Handle logout
if (isset($_GET['logout'])) {
    // Clear session
    session_destroy();
    
    // Clear all session data
    $_SESSION = array();
    
    // Destroy the session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Show logout page with JavaScript to prevent back button
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Logging Out | Smart Waste Management</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        <link rel="stylesheet" href="css/style.css">
        <style>
            body {
                background: linear-gradient(135deg, #1b5e20, #2e7d32);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .logout-container {
                background: white;
                border-radius: 15px;
                padding: 40px;
                text-align: center;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                max-width: 500px;
                width: 90%;
            }
        </style>
        <script>
            // Prevent back button after logout
            history.pushState(null, null, location.href);
            window.onpopstate = function () {
                history.go(1);
            };
            
            // Clear browser cache
            if (window.performance && window.performance.navigation.type === window.performance.navigation.TYPE_BACK_FORWARD) {
                window.location.replace('index.php');
            }
            
            // Redirect to home page after 2 seconds
            setTimeout(function() {
                window.location.replace('index.php');
            }, 2000);
        </script>
    </head>
    <body>
        <div class="logout-container">
            <div class="mb-4">
                <i class="fas fa-sign-out-alt fa-4x text-success"></i>
            </div>
            <h3 class="mb-3">Logging Out...</h3>
            <p class="text-muted mb-4">You have been successfully logged out from your account.</p>
            <div class="spinner-border text-success" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-3">Redirecting to homepage...</p>
        </div>
    </body>
    </html>
    <?php
    exit();
}

// Handle account deletion request
if (isset($_GET['delete_request'])) {
    echo '<script>
    if (confirm("Are you sure you want to delete your account? This action cannot be undone!")) {
        window.location.href = "delete_account.php";
    }
    </script>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard | Smart Waste Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script>
        // Prevent back button to login page
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
            history.go(1);
        };
    </script>
    <style>
        /* Sidebar Styles */
        .sidebar-collapse {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100vh;
            background: linear-gradient(135deg, #1b5e20, #2e7d32);
            color: white;
            z-index: 1000;
            transition: transform 0.3s ease;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            overflow-y: auto;
        }
        
        .sidebar-collapse.collapsed {
            transform: translateX(-250px);
        }
        
        /* Toggle Button */
        .sidebar-toggle {
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: #2e7d32;
            color: white;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }
        
        .sidebar-toggle:hover {
            background: #1b5e20;
            transform: scale(1.1);
        }
        
        .sidebar-toggle.collapsed {
            left: 15px;
        }
        
        /* Main Content */
        .user-content {
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
            min-height: 100vh;
        }
        
        .user-content.expanded {
            margin-left: 0;
        }
        
        /* User Header */
        .user-header {
            background: linear-gradient(135deg, #2e7d32, #1b5e20);
            padding: 15px 20px;
            color: white;
            position: sticky;
            top: 0;
            z-index: 999;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-left: 250px;
            transition: margin-left 0.3s ease;
        }
        
        .user-header.expanded {
            margin-left: 0;
        }
        
        /* Sidebar Content */
        .user-profile {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .user-profile i {
            font-size: 50px;
            margin-bottom: 15px;
            opacity: 0.9;
        }
        
        .user-profile h6 {
            font-size: 16px;
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        .user-profile small {
            font-size: 12px;
            opacity: 0.8;
        }
        
        .sidebar-nav {
            padding: 20px 15px;
        }
        
        .sidebar-nav .nav-link {
            color: white;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 5px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            text-decoration: none;
            cursor: pointer;
        }
        
        .sidebar-nav .nav-link:hover,
        .sidebar-nav .nav-link.active {
            background-color: rgba(255, 255, 255, 0.15);
            padding-left: 20px;
        }
        
        .sidebar-nav .nav-link i {
            width: 25px;
            font-size: 16px;
        }
        
        /* Dashboard content styling */
        .tab-content {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            min-height: calc(100vh - 150px);
        }
        
        .tab-pane {
            display: none;
        }
        
        .tab-pane.active {
            display: block;
        }
        
        /* Dashboard Cards */
        .dashboard-card {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            background: white;
            border-left: 5px solid #2e7d32;
        }
        
        .dashboard-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.12);
        }
        
        .dashboard-card i {
            font-size: 28px;
            opacity: 0.8;
            color: #2e7d32;
        }
        
        /* Table Styles */
        .table-container {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 15px;
        }
        
        /* Scrollbar styling */
        .sidebar-collapse::-webkit-scrollbar,
        .table-responsive::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        
        .sidebar-collapse::-webkit-scrollbar-track,
        .table-responsive::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 3px;
        }
        
        .sidebar-collapse::-webkit-scrollbar-thumb,
        .table-responsive::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 3px;
        }
        
        .sidebar-collapse::-webkit-scrollbar-thumb:hover,
        .table-responsive::-webkit-scrollbar-thumb:hover {
            background: #a1a1a1;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .sidebar-collapse {
                width: 200px;
            }
            
            .sidebar-collapse.collapsed {
                transform: translateX(-200px);
            }
            
            .user-content {
                margin-left: 200px;
            }
            
            .user-header {
                margin-left: 200px;
            }
        }
        
        /* Badges */
        .badge {
            font-size: 12px;
            padding: 5px 10px;
            border-radius: 10px;
            font-weight: 500;
        }
        
        .bg-pending {
            background-color: #ffc107;
            color: #000;
        }
        
        .bg-accepted {
            background-color: #28a745;
            color: white;
        }
        
        .bg-rejected {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>
    <!-- Sidebar Toggle Button -->
    <button class="sidebar-toggle" id="sidebarToggle">
        <i class="fas fa-bars"></i>
    </button>

    <!-- User Sidebar -->
    <div class="sidebar-collapse" id="sidebar">
        <div class="user-profile">
            <i class="fas fa-user-circle"></i>
            <h6><?php echo htmlspecialchars($fullname); ?></h6>
            <small>ID: <?php echo $user_id; ?></small>
        </div>
        
        <div class="sidebar-nav">
            <a class="nav-link active" data-tab="dashboard">
                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
            </a>
            <a class="nav-link" data-tab="create_request">
                <i class="fas fa-plus-circle me-2"></i> Create Request
            </a>
            <a class="nav-link" data-tab="view_requests">
                <i class="fas fa-list me-2"></i> View Requests
            </a>
            <a class="nav-link" data-tab="edit_account">
                <i class="fas fa-user-edit me-2"></i> Edit Account
            </a>
            <a class="nav-link text-warning" href="?delete_request=true" onclick="return confirm('Are you sure you want to delete your account?')">
                <i class="fas fa-trash-alt me-2"></i> Delete Account
            </a>
        </div>
    </div>

    <!-- User Header -->
    <div class="user-header" id="userHeader">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0"><i class="fas fa-user-circle me-2"></i>User Dashboard</h5>
                    <small class="opacity-75">Welcome, <?php echo htmlspecialchars($fullname); ?></small>
                </div>
                <div>
                    <a href="?logout=true" class="btn btn-outline-light btn-sm" onclick="return confirm('Are you sure you want to logout?')">
                        <i class="fas fa-sign-out-alt me-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="user-content" id="userContent">
        <div class="tab-content" id="tabContent">
            <?php
            // Include all tab content files
            $tab = isset($_GET['tab']) ? $_GET['tab'] : 'dashboard';
            
            // Define tab content
            $tabs = [
                'dashboard' => 'dashboard_home.php',
                'create_request' => 'create_request.php',
                'view_requests' => 'view_requests.php',
                'edit_account' => 'edit_account.php'
            ];
            
            // Show active tab content
            foreach ($tabs as $tabName => $tabFile) {
                $isActive = ($tab === $tabName) ? 'active' : '';
                echo '<div class="tab-pane ' . $isActive . '" id="' . $tabName . 'Tab">';
                if (file_exists($tabFile)) {
                    include $tabFile;
                } else {
                    echo '<div class="alert alert-danger">Content not found for ' . $tabName . '</div>';
                }
                echo '</div>';
            }
            ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Sidebar Toggle Functionality
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const userContent = document.getElementById('userContent');
    const userHeader = document.getElementById('userHeader');
    
    // Check if sidebar state is saved in localStorage
    const isSidebarCollapsed = localStorage.getItem('userSidebarCollapsed') === 'true';
    
    // Initialize sidebar state
    if (isSidebarCollapsed) {
        sidebar.classList.add('collapsed');
        userContent.classList.add('expanded');
        userHeader.classList.add('expanded');
        sidebarToggle.innerHTML = '<i class="fas fa-bars"></i>';
        sidebarToggle.classList.add('collapsed');
    }
    
    // Toggle sidebar
    sidebarToggle.addEventListener('click', function() {
        sidebar.classList.toggle('collapsed');
        userContent.classList.toggle('expanded');
        userHeader.classList.toggle('expanded');
        
        // Change icon
        if (sidebar.classList.contains('collapsed')) {
            this.innerHTML = '<i class="fas fa-bars"></i>';
            this.classList.add('collapsed');
            localStorage.setItem('userSidebarCollapsed', 'true');
        } else {
            this.innerHTML = '<i class="fas fa-times"></i>';
            this.classList.remove('collapsed');
            localStorage.setItem('userSidebarCollapsed', 'false');
        }
    });
    
    // Tab switching functionality
    document.addEventListener('DOMContentLoaded', function() {
        const tabLinks = document.querySelectorAll('.sidebar-nav .nav-link:not([href])');
        const tabPanes = document.querySelectorAll('.tab-pane');
        
        // Get current tab from URL or default to dashboard
        const urlParams = new URLSearchParams(window.location.search);
        const currentTab = urlParams.get('tab') || 'dashboard';
        
        // Initialize - show current tab
        showTab(currentTab);
        
        // Update active link
        tabLinks.forEach(link => {
            const tabId = link.getAttribute('data-tab');
            if (tabId === currentTab) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
            
            // Add click event
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const tabId = this.getAttribute('data-tab');
                showTab(tabId);
                
                // Update URL without page reload
                const url = new URL(window.location);
                url.searchParams.set('tab', tabId);
                window.history.pushState({}, '', url);
                
                // Update active state
                tabLinks.forEach(l => l.classList.remove('active'));
                this.classList.add('active');
            });
        });
    });
    
    function showTab(tabId) {
        // Hide all tab panes
        const tabPanes = document.querySelectorAll('.tab-pane');
        tabPanes.forEach(pane => {
            pane.classList.remove('active');
        });
        
        // Show selected tab pane
        const activeTab = document.getElementById(tabId + 'Tab');
        if (activeTab) {
            activeTab.classList.add('active');
        }
    }
    
    // Handle browser back/forward for tabs
    window.addEventListener('popstate', function() {
        const urlParams = new URLSearchParams(window.location.search);
        const currentTab = urlParams.get('tab') || 'dashboard';
        showTab(currentTab);
        
        // Update active link
        const tabLinks = document.querySelectorAll('.sidebar-nav .nav-link:not([href])');
        tabLinks.forEach(link => {
            const tabId = link.getAttribute('data-tab');
            if (tabId === currentTab) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    });
    
    // Make tables sortable
    document.addEventListener('DOMContentLoaded', function() {
        // Add sorting functionality to table headers
        const tables = document.querySelectorAll('table');
        tables.forEach(table => {
            const headers = table.querySelectorAll('th');
            headers.forEach((header, index) => {
                if (!header.querySelector('button') && !header.querySelector('a')) { // Don't add to action columns
                    header.style.cursor = 'pointer';
                    header.addEventListener('click', () => {
                        sortTable(table, index);
                    });
                }
            });
        });
    });
    
    function sortTable(table, column) {
        const tbody = table.querySelector('tbody');
        if (!tbody) return;
        
        const rows = Array.from(tbody.querySelectorAll('tr'));
        
        const isAscending = table.getAttribute('data-sort-direction') !== 'asc';
        
        rows.sort((a, b) => {
            const aText = a.cells[column].textContent.trim();
            const bText = b.cells[column].textContent.trim();
            
            // Check if values are numeric
            const aNum = parseFloat(aText.replace(/[^0-9.-]+/g, ""));
            const bNum = parseFloat(bText.replace(/[^0-9.-]+/g, ""));
            
            if (!isNaN(aNum) && !isNaN(bNum)) {
                return isAscending ? aNum - bNum : bNum - aNum;
            } else {
                return isAscending ? 
                    aText.localeCompare(bText) : 
                    bText.localeCompare(aText);
            }
        });
        
        // Clear existing rows
        while (tbody.firstChild) {
            tbody.removeChild(tbody.firstChild);
        }
        
        // Append sorted rows
        rows.forEach(row => tbody.appendChild(row));
        
        // Toggle sort direction
        table.setAttribute('data-sort-direction', isAscending ? 'asc' : 'desc');
        
        // Update sort indicator
        const headers = table.querySelectorAll('th');
        headers.forEach(header => {
            header.classList.remove('sort-asc', 'sort-desc');
        });
        
        const currentHeader = table.querySelectorAll('th')[column];
        if (currentHeader) {
            currentHeader.classList.add(isAscending ? 'sort-asc' : 'sort-desc');
        }
    }
    
    // Add CSS for sort indicators
    const style = document.createElement('style');
    style.textContent = `
        .sort-asc::after {
            content: " \\25B2";
            font-size: 10px;
            opacity: 0.7;
        }
        .sort-desc::after {
            content: " \\25BC";
            font-size: 10px;
            opacity: 0.7;
        }
        
        /* Form styles */
        .form-control:focus {
            border-color: #2e7d32;
            box-shadow: 0 0 0 0.25rem rgba(46, 125, 50, 0.25);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #2e7d32, #1b5e20);
            border: none;
        }
        
        .btn-success:hover {
            background: linear-gradient(135deg, #1b5e20, #2e7d32);
        }
    `;
    document.head.appendChild(style);
    </script>
</body>
</html>
