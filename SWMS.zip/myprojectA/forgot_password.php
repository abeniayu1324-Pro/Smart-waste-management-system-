<?php

session_start();
include_once 'config/database.php';
include_once 'includes/functions.php';


// Handle ID and email submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['userId']) && isset($_POST['email'])) {
    $userId = sanitize($_POST['userId']);
    $email = sanitize($_POST['email']);
    
    // Check if user exists with this ID and email
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ? AND email = ?");
    $stmt->bind_param("ss", $userId, $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        // User found - set session
        $_SESSION['reset_user_id'] = $userId;
        $_SESSION['reset_email'] = $email;
        
        // Redirect to reset page
        header('Location: reset.php');
        exit();
    } else {
        // User not found - show error
        $error = "User ID and Email combination not found in our system.";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | Smart Waste Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card border-primary shadow-lg">
                    <div class="card-header bg-primary text-white">
                        <h4><i class="fas fa-key me-2"></i>Forgot Password - Verify Identity</h4>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                        <div class="alert alert-danger">
                            <?php echo $error; ?>
                        </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="forgot_password.php">
                            <div class="mb-3">
                                <label for="userId" class="form-label">User ID *</label>
                                <input type="text" class="form-control" id="userId" name="userId" required>
                                <small class="text-muted">Enter your User ID </small>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Registered Email *</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                                <small class="text-muted">Enter the email you used during registration</small>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <a href="index.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Home
                                </a>
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-check"></i> Verify Identity
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php
$conn->close();
?>