<?php
if (!isset($_SESSION)) {
    session_start();
}
include_once 'config/database.php';
include_once 'includes/functions.php';

// Check if user is logged in
if (!isLoggedIn() || $_SESSION['user_type'] !== 'user') {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$fullname = $_SESSION['fullname'];

$message = '';
$update_success = false;
$new_username = '';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['fullname'])) {
    // Get form data - use isset() to check each field
    $new_fullname = isset($_POST['fullname']) ? sanitize($_POST['fullname']) : '';
    $current_password = isset($_POST['current_password']) ? $_POST['current_password'] : '';
    $new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
    
    // Validate required fields
    if (empty($new_fullname) || empty($current_password)) {
        $message = '<div class="alert alert-danger">Full name and current password are required!</div>';
    } else {
        // Verify current password
        $stmt = $conn->prepare("SELECT password FROM users WHERE user_id = ?");
        $stmt->bind_param("s", $user_id);
        $stmt->execute();
        $stmt->bind_result($db_password);
        $stmt->fetch();
        $stmt->close();
        
        if ($db_password !== $current_password) {
            $message = '<div class="alert alert-danger">Current password is incorrect!</div>';
        } elseif ($new_password && $new_password !== $confirm_password) {
            $message = '<div class="alert alert-danger">New passwords do not match!</div>';
        } else {
            // Generate new username
            $new_username = generateUsername($new_fullname);
            
            // If no new password provided, keep the old one
            $final_password = $new_password ? $new_password : $current_password;
            
            // Update user information
            $update_stmt = $conn->prepare("UPDATE users SET fullname = ?, username = ?, password = ? WHERE user_id = ?");
            $update_stmt->bind_param("ssss", $new_fullname, $new_username, $final_password, $user_id);
            
            if ($update_stmt->execute()) {
                // Log edit history
                $history_stmt = $conn->prepare("INSERT INTO edited_accounts (user_id, old_username, new_username, old_fullname, new_fullname) VALUES (?, ?, ?, ?, ?)");
                $history_stmt->bind_param("sssss", $user_id, $username, $new_username, $fullname, $new_fullname);
                $history_stmt->execute();
                $history_stmt->close();
                
                // Set success flag
                $update_success = true;
                
                // Show success message
                $message = '<div class="alert alert-success">
                    <h5><i class="fas fa-check-circle"></i> Account Updated Successfully!</h5>
                    <p><strong>New Username:</strong> ' . $new_username . '</p>
                    <p><strong>User ID:</strong> ' . $user_id . ' (remains the same)</p>
                    <p>You will be automatically logged out in <span id="countdown">10</span> seconds to apply changes.</p>
                </div>';
                
            } else {
                $message = '<div class="alert alert-danger">Failed to update account: ' . $conn->error . '</div>';
            }
            $update_stmt->close();
        }
    }
}
?>
<div class="container">
    <h3 class="mb-4"><i class="fas fa-user-edit text-success"></i> Edit Account Information</h3>
    
    <?php echo $message; ?>
    
    <?php if ($update_success): ?>
    <!-- Countdown and Auto Logout Section -->
    <div class="card border-success">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0"><i class="fas fa-clock"></i> Automatic Logout in Progress</h5>
        </div>
        <div class="card-body text-center">
            <div class="mb-4">
                <i class="fas fa-user-circle fa-5x text-success mb-3"></i>
                <h4>Account Updated Successfully!</h4>
                <p class="lead">Your account information has been updated.</p>
            </div>
            
            <div class="alert alert-info">
                <h5><i class="fas fa-info-circle"></i> Your New Credentials:</h5>
                <div class="row mt-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label"><strong>User ID:</strong></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-id-card"></i></span>
                                <input type="text" class="form-control fw-bold" value="<?php echo $user_id; ?>" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label"><strong>New Username:</strong></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                                <input type="text" class="form-control fw-bold text-success" value="<?php echo $new_username; ?>" readonly>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Countdown Progress Bar -->
            <div class="mb-4">
                <div class="d-flex justify-content-between mb-2">
                    <span>Time until logout:</span>
                    <span><strong id="countdownDisplay">10</strong> seconds</span>
                </div>
                <div class="progress" style="height: 20px;">
                    <div id="countdownProgress" class="progress-bar progress-bar-striped progress-bar-animated bg-success" 
                         style="width: 100%"></div>
                </div>
            </div>
            
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i>
                <strong>Important:</strong> You will be automatically logged out. Please login again with your new username.
            </div>
            
            <div class="mt-4">
                <a href="index.php#loginModal" class="btn btn-success btn-lg me-3">
                    <i class="fas fa-sign-in-alt"></i> Login Now
                </a>
                <button onclick="logoutNow()" class="btn btn-outline-danger btn-lg">
                    <i class="fas fa-sign-out-alt"></i> Logout Now
                </button>
            </div>
        </div>
    </div>
    
    <script>
    let countdown = 10;
    const countdownElement = document.getElementById('countdownDisplay');
    const progressBar = document.getElementById('countdownProgress');
    
    function updateCountdown() {
        countdown--;
        countdownElement.textContent = countdown;
        
        // Update progress bar
        const progressPercentage = (countdown / 10) * 100;
        progressBar.style.width = progressPercentage + '%';
        
        // Change color when time is running out
        if (countdown <= 3) {
            progressBar.className = 'progress-bar progress-bar-striped progress-bar-animated bg-danger';
        } else if (countdown <= 6) {
            progressBar.className = 'progress-bar progress-bar-striped progress-bar-animated bg-warning';
        }
        
        if (countdown <= 0) {
            clearInterval(countdownInterval);
            performLogout();
        }
    }
    
    function performLogout() {
        // Redirect to logout page
        window.location.href = 'user_dashboard.php?logout=true';
    }
    
    function logoutNow() {
        if (confirm('Are you sure you want to logout now?')) {
            performLogout();
        }
    }
    
    // Start countdown
    const countdownInterval = setInterval(updateCountdown, 1000);
    
    // Prevent back button
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
    </script>
    
    <?php else: ?>
    <!-- Edit Account Form (Only shows if not successful yet) -->
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="fas fa-user-cog"></i> Update Details</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="user_id" class="form-label">User ID</label>
                            <input type="text" class="form-control" value="<?php echo $user_id; ?>" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label for="fullname" class="form-label">Full Name *</label>
                            <input type="text" class="form-control" id="fullname" name="fullname" 
                                   value="<?php echo htmlspecialchars($fullname); ?>" 
                                   pattern="[A-Za-z\s]{2,50}"
                                   title="Only letters and spaces are allowed (2-50 characters)"
                                   oninput="validateFullname(this)"
                                   required>
                            <div class="invalid-feedback">Please enter a valid name (letters and spaces only, 2-50 characters)</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="username" class="form-label">Current Username</label>
                            <input type="text" class="form-control" value="<?php echo $username; ?>" readonly>
                            <small class="text-muted">Will be updated based on new full name</small>
                        </div>
                        
                        <hr>
                        
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Current Password *</label>
                            <div class="password-container">
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                                <button type="button" class="password-toggle">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <div class="password-container">
                                <input type="password" class="form-control" id="new_password" name="new_password">
                                <button type="button" class="password-toggle">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <small class="text-muted">Leave blank to keep current password</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <div class="password-container">
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                                <button type="button" class="password-toggle">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i>
                            <strong>Note:</strong> After updating, you will be automatically logged out in 10 seconds and need to login with your new username.
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="user_dashboard.php?tab=dashboard" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-success" onclick="return validateEditForm()">
                                <i class="fas fa-save"></i> Update Account
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-info-circle"></i> Important Information</h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <h6><i class="fas fa-user-circle"></i> Username Generation</h6>
                        <p>Your username is automatically generated from your full name:</p>
                        <p><code>FullName@swms.com</code></p>
                        <p>Example: "John Doe" becomes "JohnDoe@swms.com"</p>
                    </div>
                    
                    <div class="alert alert-warning">
                        <h6><i class="fas fa-exclamation-triangle"></i> What happens after update:</h6>
                        <ul class="mb-0">
                            <li>Your username will be updated automatically</li>
                            <li>You will see a 10-second countdown</li>
                            <li>System will automatically log you out</li>
                            <li>Login again with your new username</li>
                            <li>Your User ID remains the same</li>
                        </ul>
                    </div>
                    
                    <div class="alert alert-success">
                        <h6><i class="fas fa-shield-alt"></i> Security Note</h6>
                        <p>Automatic logout ensures your account security when credentials are changed.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    // Validate fullname for edit account form
    function validateFullname(input) {
        // Remove any numbers that might have been typed
        input.value = input.value.replace(/[0-9]/g, '');
        
        // Validate pattern
        const pattern = /^[A-Za-z\s]{2,50}$/;
        
        if (pattern.test(input.value)) {
            input.classList.remove('is-invalid');
            input.classList.add('is-valid');
            return true;
        } else {
            input.classList.remove('is-valid');
            input.classList.add('is-invalid');
            return false;
        }
    }
    
    // Validate edit form before submission
    function validateEditForm() {
        const fullname = document.getElementById('fullname');
        
        if (!validateFullname(fullname)) {
            alert('Please enter a valid full name (letters and spaces only, 2-50 characters)');
            fullname.focus();
            return false;
        }
        
        // Add password validation if needed
        const newPassword = document.getElementById('new_password');
        const confirmPassword = document.getElementById('confirm_password');
        
        if (newPassword.value && newPassword.value !== confirmPassword.value) {
            alert('New passwords do not match!');
            return false;
        }
        
        return true;
    }
    
    // Password toggle functionality
    document.addEventListener('DOMContentLoaded', function() {
        const passwordToggles = document.querySelectorAll('.password-toggle');
        passwordToggles.forEach(toggle => {
            toggle.addEventListener('click', function() {
                const passwordInput = this.previousElementSibling;
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                this.querySelector('i').classList.toggle('fa-eye');
                this.querySelector('i').classList.toggle('fa-eye-slash');
            });
        });
        
        // Also validate fullname on blur
        const fullnameInput = document.getElementById('fullname');
        if (fullnameInput) {
            fullnameInput.addEventListener('blur', function() {
                validateFullname(this);
            });
        }
    });
    </script>
    <?php endif; ?>
</div>