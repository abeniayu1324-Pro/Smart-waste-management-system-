<?php
session_start();
include_once 'config/database.php';
include_once 'includes/functions.php';



// Check if user has completed ID+email verification
if (!isset($_SESSION['reset_user_id']) || !isset($_SESSION['reset_email'])) {
    echo '<script>
        alert("Please verify your identity first using the forgot password link.");
        window.location.href = "index.php";
    </script>';
    exit();
}

$user_id = $_SESSION['reset_user_id'];
$email = $_SESSION['reset_email'];

// Handle password reset
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = sanitize($_POST['username']);
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate passwords match
    if ($new_password !== $confirm_password) {
        $message = '<div class="alert alert-danger">Passwords do not match!</div>';
    } else {
        // Update password
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ? AND email = ? AND username = ?");
        $stmt->bind_param("ssss", $new_password, $user_id, $email, $username);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            // Clear session
            unset($_SESSION['reset_user_id']);
            unset($_SESSION['reset_email']);
            session_destroy();
            
            // Show success message
            ?>
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Password Reset Successful</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
                <link rel="stylesheet" href="css/style.css">
                <style>
                    body {
                        background: linear-gradient(135deg, #1b5e20, #2e7d32);
                        min-height: 100vh;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        padding: 20px;
                    }
                    .success-container {
                        background: white;
                        border-radius: 15px;
                        padding: 40px;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                        max-width: 500px;
                        width: 100%;
                    }
                </style>
                <script>
                    // Function to open login modal
                    function openLoginModal() {
                        // Store a flag in localStorage to trigger modal
                        localStorage.setItem('showLoginModal', 'true');
                        window.location.href = 'index.php';
                    }
                    
                    // Alternative method using URL parameter
                    function redirectToLogin() {
                        window.location.href = 'index.php?showLogin=true';
                    }
                </script>
            </head>
            <body>
                <div class="success-container">
                    <div class="text-center mb-4">
                        <i class="fas fa-check-circle fa-4x text-success"></i>
                        <h3 class="mt-3 text-success">Password Reset Successful!</h3>
                        <p class="text-muted">Your password has been successfully reset.</p>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i>
                        You can now login with your new password.
                    </div>
                    
                    <div class="d-grid gap-2">
                        <!-- Method 1: Direct link with parameter -->
                        <a href="index.php?showLogin=true" class="btn btn-success btn-lg">
                            <i class="fas fa-sign-in-alt me-2"></i> Go to Login
                        </a>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="fas fa-home me-2"></i> Back to Home
                        </a>
                    </div>
                </div>
                
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            </body>
            </html>
            <?php
            exit();
        } else {
            $message = '<div class="alert alert-danger">Invalid username or verification failed!</div>';
        }
        $stmt->close();
    }
}

// Get user info
$stmt = $conn->prepare("SELECT username FROM users WHERE user_id = ? AND email = ?");
$stmt->bind_param("ss", $user_id, $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | Smart Waste Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .reset-container {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 100%;
        }
        
    </style>
</head>
<body>
    <div class="reset-container">
        <div class="text-center mb-4">
            <i class="fas fa-key fa-3x text-primary mb-3"></i>
            <h3>Reset Your Password</h3>
        </div>
        
        <?php echo $message; ?>
        
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i>
            Resetting password for:<br>
            <strong>User ID:</strong> <?php echo $user_id; ?><br>
            <strong>Email:</strong> <?php echo htmlspecialchars($email); ?>
        </div>
        
        <form method="POST" action="">
            <div class="mb-3">
                <label for="username" class="form-label">Username *</label>
                <input type="text" class="form-control" id="username" name="username" 
                       value="<?php echo isset($user['username']) ? $user['username'] : ''; ?>" required>
                <small class="text-muted">Enter your username (FullName@swms.com)</small>
            </div>
            
            <div class="mb-3">
                <label for="new_password" class="form-label">New Password *</label>
                <div class="password-container">
                    <input type="password" class="form-control" id="new_password" name="new_password" required>
                    <button type="button" class="password-toggle">
                        
                    </button>
                </div>
                <small class="text-muted">6-8 chars, 1 uppercase, 1 lowercase, 1 number</small>
            </div>
            
            <div class="mb-3">
                <label for="confirm_password" class="form-label">Confirm New Password *</label>
                <div class="password-container">
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    <button type="button" class="password-toggle">
                        
                    </button>
                </div>
            </div>
            
            <div class="d-flex justify-content-between">
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancel
                </a>
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-save"></i> Reset Password
                </button>
            </div>
        </form>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Password toggle functionality
    document.addEventListener('DOMContentLoaded', function() {
        const passwordToggles = document.querySelectorAll('.password-toggle');
        passwordToggles.forEach(toggle => {
            toggle.addEventListener('click', function() {
                const passwordInput = this.previousElementSibling;
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                this.querySelector('i').classList.toggle('fa-eye');
                this.querySelector('i').classList.toggle('fa-eye-slash');
            });
        });
    });
    </script>
</body>
</html>
<?php
$conn->close();
?>