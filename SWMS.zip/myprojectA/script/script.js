//swms js code
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Password toggle functionality
    const passwordToggles = document.querySelectorAll('.password-toggle');
    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const passwordInput = this.previousElementSibling;
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.querySelector('i').classList.toggle('fa-eye');
            this.querySelector('i').classList.toggle('fa-eye-slash');
        });
    });

    // Form validation for signup
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            validateSignupForm();
        });
    }

    // Form validation for login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            validateLoginForm();
        });
    }

    // Phone number validation
    const phoneInputs = document.querySelectorAll('input[type="tel"]');
    phoneInputs.forEach(input => {
        input.addEventListener('input', function() {
            validatePhoneNumber(this);
        });
    });

    // Scroll animations
    setupScrollAnimations();

    // Confirm before delete
    const deleteButtons = document.querySelectorAll('.btn-delete');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete? This action cannot be undone!')) {
                e.preventDefault();
            }
        });
    });

    // Confirm before actions
    const actionButtons = document.querySelectorAll('.btn-action');
    actionButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const action = this.getAttribute('data-action');
            if (!confirm(`Are you sure you want to ${action}?`)) {
                e.preventDefault();
            }
        });
    });

    // Logout back button prevention
    if (window.location.pathname.includes('logout.php') || 
        window.location.pathname.includes('login.php')) {
        history.pushState(null, null, location.href);
        window.onpopstate = function() {
            history.go(1);
        };
    }

    // Auto-generate username in signup form
    const fullnameInput = document.getElementById('fullname');
    if (fullnameInput) {
        fullnameInput.addEventListener('blur', function() {
            generateUsernameFromFullname(this.value);
        });
    }
});

// Generate username from fullname
function generateUsernameFromFullname(fullname) {
    if (fullname.trim()) {
        const username = fullname.replace(/\s+/g, '') + '@swms.com';
        const usernameDisplay = document.getElementById('generatedUsername');
        if (usernameDisplay) {
            usernameDisplay.textContent = username.toLowerCase();
            usernameDisplay.classList.remove('d-none');
        }
    }
}

// Validate signup form
function validateSignupForm() {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const email = document.getElementById('email').value;
    
    // Password validation
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,8}$/;
    
    if (!passwordRegex.test(password)) {
        showMessage('Password must contain 1 uppercase, 1 lowercase, 1 number, and be 6-8 characters long!', 'danger');
        return false;
    }
    
    if (password !== confirmPassword) {
        showMessage('Passwords do not match!', 'danger');
        return false;
    }
    
    // Email validation
    const emailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
    if (!emailRegex.test(email)) {
        showMessage('Please use a valid @gmail.com email address!', 'danger');
        return false;
    }
    
    // If all validations pass
    document.getElementById('signupForm').submit();
}

// Validate login form
function validateLoginForm() {
    const userId = document.getElementById('userId').value;
    const username = document.getElementById('username').value;
    
    if (!userId || !username) {
        showMessage('Please fill in all required fields!', 'danger');
        return false;
    }
    
    // If validations pass
    document.getElementById('loginForm').submit();
}

// Validate phone number (Ethiopian format)
function validatePhoneNumber(input) {
    const phone = input.value.replace(/\D/g, '');
    
    if (phone.length >= 9) {
        const formatted = '+251 ' + phone.substring(phone.length - 9);
        input.value = formatted;
    }
    
    const phoneRegex = /^\+251\s?\d{9}$/;
    if (phoneRegex.test(input.value)) {
        input.classList.remove('is-invalid');
        input.classList.add('is-valid');
    } else {
        input.classList.remove('is-valid');
        input.classList.add('is-invalid');
    }
}

// Setup scroll animations
function setupScrollAnimations() {
    const animatedElements = document.querySelectorAll('.animate-left, .animate-right, .animate-up');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-show');
            }
        });
    }, {
        threshold: 0.1
    });
    
    animatedElements.forEach(element => {
        observer.observe(element);
    });
}

// Show message function
function showMessage(message, type = 'success') {
    // Remove any existing alerts
    const existingAlert = document.querySelector('.alert-message');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    // Create new alert
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show alert-message position-fixed`;
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    
    alertDiv.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check' : 'exclamation'}-circle"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}

// Confirm action function
function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// Toggle request status
function toggleRequestStatus(requestId, currentStatus) {
    confirmAction(`Are you sure you want to change this request status?`, function() {
        // This would typically be an AJAX call
        console.log(`Changing request ${requestId} status from ${currentStatus}`);
        // Update UI
        const statusElement = document.querySelector(`.status-${requestId}`);
        if (statusElement) {
            const newStatus = currentStatus === 'pending' ? 'accepted' : 'pending';
            statusElement.textContent = newStatus;
            statusElement.className = `badge bg-${newStatus === 'accepted' ? 'success' : 'warning'}`;
            showMessage(`Request ${requestId} status updated to ${newStatus}`, 'success');
        }
    });
}

// Toggle user status
function toggleUserStatus(userId, currentStatus) {
    confirmAction(`Are you sure you want to ${currentStatus === 'active' ? 'deactivate' : 'activate'} this user?`, function() {
        // This would typically be an AJAX call
        console.log(`Changing user ${userId} status from ${currentStatus}`);
        // Update UI
        const statusElement = document.querySelector(`.user-status-${userId}`);
        if (statusElement) {
            const newStatus = currentStatus === 'active' ? 'deactivated' : 'active';
            statusElement.textContent = newStatus;
            statusElement.className = `badge bg-${newStatus === 'active' ? 'info' : 'secondary'}`;
            showMessage(`User ${userId} has been ${newStatus}`, 'success');
        }
    });
}
// Handle forgot password form submission
function handleForgotPassword() {
    const userId = document.getElementById('forgotUserId').value;
    const email = document.getElementById('forgotEmail').value;
    
    if (!userId || !email) {
        showMessage('Please enter both User ID and Email!', 'danger');
        return false;
    }
    
    // Create loading state
    const submitBtn = document.querySelector('#forgotForm button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verifying...';
    submitBtn.disabled = true;
    
    // Send AJAX request
    fetch('forgot_password.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'userId=' + encodeURIComponent(userId) + '&email=' + encodeURIComponent(email)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // Show success message
            showMessage(data.message, 'success');
            
            // Close modal
            const forgotModal = document.getElementById('forgotModal');
            const modalInstance = bootstrap.Modal.getInstance(forgotModal);
            if (modalInstance) {
                modalInstance.hide();
            }
            
            // Redirect to reset page after a short delay
            setTimeout(() => {
                window.location.href = data.redirect;
            }, 1500);
        } else {
            showMessage(data.message, 'danger');
        }
    })
    .catch(error => {
        showMessage('An error occurred. Please try again.', 'danger');
        console.error('Error:', error);
    })
    .finally(() => {
        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
    
    return false;
}

// Update the DOMContentLoaded event to handle forgot password form
document.addEventListener('DOMContentLoaded', function() {
    
    // Handle forgot password form submission
    const forgotForm = document.getElementById('forgotForm');
    if (forgotForm) {
        forgotForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleForgotPassword();
        });
    }
});

