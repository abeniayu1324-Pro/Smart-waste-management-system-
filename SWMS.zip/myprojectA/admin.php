<?php
session_start();
include_once 'config/database.php';
include_once 'includes/functions.php';



// Check if admin is logged in
if (!isset($_SESSION['admin_id']) || $_SESSION['user_type'] !== 'admin') {
    // Redirect to login page
    echo '<script>
        alert("Please login as admin first!");
        window.location.href = "index.php#loginModal";
    </script>';
    exit();
}

// Admin is logged in - Show dashboard
$admin_id = $_SESSION['admin_id'];

// Handle actions
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'toggle_user':
            $user_id = sanitize($_GET['user_id']);
            $current_status = sanitize($_GET['status']);
            $new_status = $current_status == 'active' ? 'deactivated' : 'active';
            
            $stmt = $conn->prepare("UPDATE users SET status = ? WHERE user_id = ?");
            $stmt->bind_param("ss", $new_status, $user_id);
            $stmt->execute();
            $stmt->close();
            
            echo '<script>alert("User ' . $user_id . ' has been ' . $new_status . '"); window.location.href = "admin.php";</script>';
            break;
            
        case 'update_request':
            $request_id = sanitize($_GET['request_id']);
            $new_status = sanitize($_GET['status']);
            
            $stmt = $conn->prepare("UPDATE requests SET status = ? WHERE request_id = ?");
            $stmt->bind_param("si", $new_status, $request_id);
            $stmt->execute();
            $stmt->close();
            
            echo '<script>alert("Request #' . $request_id . ' status updated to ' . $new_status . '"); window.location.href = "admin.php";</script>';
            break;
            
        case 'logout':
            // Clear session
            session_destroy();
            
            // Clear all session data
            $_SESSION = array();
            
            // Destroy the session cookie
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000,
                    $params["path"], $params["domain"],
                    $params["secure"], $params["httponly"]
                );
            }
            
            // Show logout page with JavaScript to prevent back button
            ?>
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Logging Out | Smart Waste Management</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
                <link rel="stylesheet" href="css/style.css">
                <style>
                    body {
                        background: linear-gradient(135deg, #1b5e20, #2e7d32);
                        min-height: 100vh;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }
                    .logout-container {
                        background: white;
                        border-radius: 15px;
                        padding: 40px;
                        text-align: center;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                        max-width: 500px;
                        width: 90%;
                    }
                </style>
                <script>
                    // Prevent back button after logout
                    history.pushState(null, null, location.href);
                    window.onpopstate = function () {
                        history.go(1);
                    };
                    
                    // Clear browser cache
                    if (window.performance && window.performance.navigation.type === window.performance.navigation.TYPE_BACK_FORWARD) {
                        window.location.replace('index.php');
                    }
                    
                    // Redirect to home page after 2 seconds
                    setTimeout(function() {
                        window.location.replace('index.php');
                    }, 2000);
                </script>
            </head>
            <body>
                <div class="logout-container">
                    <div class="mb-4">
                        <i class="fas fa-sign-out-alt fa-4x text-success"></i>
                    </div>
                    <h3 class="mb-3">Logging Out...</h3>
                    <p class="text-muted mb-4">You have been successfully logged out from the admin dashboard.</p>
                    <div class="spinner-border text-success" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-3">Redirecting to homepage...</p>
                </div>
            </body>
            </html>
            <?php
            exit();
            break;
    }
}

// Fetch data for dashboard
// Get all users
$users_result = $conn->query("SELECT * FROM users ORDER BY created_at DESC");

// Get all requests
$requests_result = $conn->query("SELECT r.*, u.status as user_status FROM requests r JOIN users u ON r.user_id = u.user_id ORDER BY r.created_at DESC");

// Get messages
$messages_result = $conn->query("SELECT * FROM messages ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Smart Waste Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script>
        // Prevent back button to login page
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
            history.go(1);
        };
    </script>
    <style>
        /* Sidebar Styles */
        .sidebar-collapse {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100vh;
            background: linear-gradient(135deg, #1b5e20, #2e7d32);
            color: white;
            z-index: 1000;
            transition: transform 0.3s ease;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            overflow-y: auto;
        }
        
        .sidebar-collapse.collapsed {
            transform: translateX(-250px);
        }
        
        /* Toggle Button */
        .sidebar-toggle {
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: #2e7d32;
            color: white;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }
        
        .sidebar-toggle:hover {
            background: #1b5e20;
            transform: scale(1.1);
        }
        
        .sidebar-toggle.collapsed {
            left: 15px;
        }
        
        /* Main Content */
        .admin-content {
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
            min-height: 100vh;
        }
        
        .admin-content.expanded {
            margin-left: 0;
        }
        
        /* Admin Header */
        .admin-header {
            background: linear-gradient(135deg, #2e7d32, #1b5e20);
            padding: 15px 20px;
            color: white;
            position: sticky;
            top: 0;
            z-index: 999;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-left: 250px;
            transition: margin-left 0.3s ease;
        }
        
        .admin-header.expanded {
            margin-left: 0;
        }
        
        /* Sidebar Content */
        .admin-profile {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .admin-profile i {
            font-size: 50px;
            margin-bottom: 15px;
            opacity: 0.9;
        }
        
        .admin-profile h6 {
            font-size: 16px;
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        .admin-profile small {
            font-size: 12px;
            opacity: 0.8;
        }
        
        .sidebar-nav {
            padding: 20px 15px;
        }
        
        .sidebar-nav .nav-link {
            color: white;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 5px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            text-decoration: none;
            cursor: pointer;
        }
        
        .sidebar-nav .nav-link:hover,
        .sidebar-nav .nav-link.active {
            background-color: rgba(255, 255, 255, 0.15);
            padding-left: 20px;
        }
        
        .sidebar-nav .nav-link i {
            width: 25px;
            font-size: 16px;
        }
        
        /* Compact Table Styles */
        .compact-table {
            font-size: 12px;
        }
        
        .compact-table th {
            padding: 8px 10px !important;
            font-size: 11px;
            font-weight: 600;
            background: linear-gradient(135deg, #2e7d32, #1b5e20) !important;
        }
        
        .compact-table td {
            padding: 6px 10px !important;
            font-size: 12px;
            vertical-align: middle;
        }
        
        .compact-table tr:hover {
            background-color: #f8f9fa !important;
        }
        
        .table-container {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 15px;
        }
        
        /* Small badges */
        .small-badge {
            font-size: 10px;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 500;
        }
        
        /* Small buttons */
        .small-btn {
            padding: 3px 8px;
            font-size: 11px;
            border-radius: 4px;
        }
        
        /* Tab content styling */
        .tab-content {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            min-height: calc(100vh - 150px);
        }
        
        .tab-pane {
            display: none;
        }
        
        .tab-pane.active {
            display: block;
        }
        
        /* Statistics cards */
        .stat-card {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.12);
        }
        
        .stat-card i {
            font-size: 28px;
            opacity: 0.8;
        }
        
        .stat-card h2 {
            font-size: 24px;
            font-weight: 700;
            margin: 5px 0;
        }
        
        .stat-card h6 {
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Scrollbar styling */
        .sidebar-collapse::-webkit-scrollbar,
        .table-responsive::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        
        .sidebar-collapse::-webkit-scrollbar-track,
        .table-responsive::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 3px;
        }
        
        .sidebar-collapse::-webkit-scrollbar-thumb,
        .table-responsive::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 3px;
        }
        
        .sidebar-collapse::-webkit-scrollbar-thumb:hover,
        .table-responsive::-webkit-scrollbar-thumb:hover {
            background: #a1a1a1;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .sidebar-collapse {
                width: 200px;
            }
            
            .sidebar-collapse.collapsed {
                transform: translateX(-200px);
            }
            
            .admin-content {
                margin-left: 200px;
            }
            
            .admin-header {
                margin-left: 200px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Toggle Button -->
    <button class="sidebar-toggle" id="sidebarToggle">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Admin Sidebar -->
    <div class="sidebar-collapse" id="sidebar">
        <div class="admin-profile">
            <i class="fas fa-user-shield"></i>
            <h6>System Administrator</h6>
            <small>Smart Waste Management</small>
        </div>
        
        <div class="sidebar-nav">
            <a class="nav-link active" data-tab="users">
                <i class="fas fa-users me-2"></i> Manage Users
            </a>
            <a class="nav-link" data-tab="requests">
                <i class="fas fa-list me-2"></i> Manage Requests
            </a>
            <a class="nav-link" data-tab="messages">
                <i class="fas fa-envelope me-2"></i> Messages
                <?php if ($messages_result->num_rows > 0): ?>
                <span class="badge bg-danger float-end small-badge"><?php echo $messages_result->num_rows; ?></span>
                <?php endif; ?>
            </a>
            <a class="nav-link" data-tab="stats">
                <i class="fas fa-chart-bar me-2"></i> Statistics
            </a>
        </div>
    </div>

    <!-- Admin Header -->
    <div class="admin-header" id="adminHeader">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0"><i class="fas fa-user-shield me-2"></i>Admin Dashboard</h5>
                    <small class="opacity-75">Admin ID: <?php echo $admin_id; ?></small>
                </div>
                <div>
                    <a href="?action=logout" class="btn btn-outline-light btn-sm" onclick="return confirm('Are you sure you want to logout?')">
                        <i class="fas fa-sign-out-alt me-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="admin-content" id="adminContent">
        <div class="tab-content" id="tabContent">
            <!-- Users Tab -->
            <div class="tab-pane active" id="usersTab">
                <h4 class="mb-3"><i class="fas fa-users text-success me-2"></i>Manage Users</h4>
                
                <div class="table-container">
                    <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
                        <table class="table table-hover compact-table mb-0">
                            <thead>
                                <tr>
                                    <th width="80">User ID</th>
                                    <th width="150">Username</th>
                                    <th width="120">Full Name</th>
                                    <th width="150">Email</th>
                                    <th width="80">Status</th>
                                    <th width="100">Created</th>
                                    <th width="100">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($user = $users_result->fetch_assoc()): ?>
                                <tr>
                                    <td class="fw-bold"><?php echo $user['user_id']; ?></td>
                                    <td><small><?php echo htmlspecialchars($user['username']); ?></small></td>
                                    <td><?php echo htmlspecialchars($user['fullname']); ?></td>
                                    <td><small><?php echo htmlspecialchars($user['email']); ?></small></td>
                                    <td>
                                        <span class="badge small-badge <?php echo $user['status'] == 'active' ? 'bg-success' : 'bg-danger'; ?>">
                                            <?php echo ucfirst($user['status']); ?>
                                        </span>
                                    </td>
                                    <td><small><?php echo date('M d, Y', strtotime($user['created_at'])); ?></small></td>
                                    <td>
                                        <button class="btn btn-sm btn-warning small-btn" 
                                                onclick="toggleUserStatus('<?php echo $user['user_id']; ?>', '<?php echo $user['status']; ?>')"
                                                title="<?php echo $user['status'] == 'active' ? 'Deactivate User' : 'Activate User'; ?>">
                                            <i class="fas fa-power-off"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="mt-2">
                    <small class="text-muted">Total Users: <?php echo $users_result->num_rows; ?></small>
                </div>
            </div>

            <!-- Requests Tab -->
            <div class="tab-pane" id="requestsTab">
                <h4 class="mb-3"><i class="fas fa-list text-success me-2"></i>Manage Requests</h4>
                
                <div class="table-container">
                    <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
                        <table class="table table-hover compact-table mb-0">
                            <thead>
                                <tr>
                                    <th width="60">Req ID</th>
                                    <th width="80">User ID</th>
                                    <th width="120">Username</th>
                                    <th width="100">Waste Type</th>
                                    <th width="120">Address</th>
                                    <th width="100">Phone</th>
                                    <th width="80">User Status</th>
                                    <th width="80">Req Status</th>
                                    <th width="90">Date</th>
                                    <th width="120">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($request = $requests_result->fetch_assoc()): ?>
                                <tr>
                                    <td><small class="fw-bold">#<?php echo str_pad($request['request_id'], 4, '0', STR_PAD_LEFT); ?></small></td>
                                    <td><small><?php echo $request['user_id']; ?></small></td>
                                    <td><small><?php echo htmlspecialchars($request['username']); ?></small></td>
                                    <td><small><?php echo htmlspecialchars($request['waste_type']); ?></small></td>
                                    <td><small><?php echo htmlspecialchars($request['address']); ?></small></td>
                                    <td><small><?php echo htmlspecialchars($request['phone']); ?></small></td>
                                    <td>
                                        <span class="badge small-badge <?php echo $request['user_status'] == 'active' ? 'bg-success' : 'bg-danger'; ?>">
                                            <?php echo $request['user_status'] == 'active' ? 'Active' : 'Inactive'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge small-badge 
                                            <?php 
                                            if ($request['status'] == 'pending') echo 'bg-warning';
                                            elseif ($request['status'] == 'accepted') echo 'bg-success';
                                            else echo 'bg-danger';
                                            ?>">
                                            <?php echo ucfirst($request['status']); ?>
                                        </span>
                                    </td>
                                    <td><small><?php echo date('M d, Y', strtotime($request['created_at'])); ?></small></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <?php if ($request['status'] == 'pending'): ?>
                                            <button class="btn btn-success small-btn" 
                                                    onclick="updateRequestStatus(<?php echo $request['request_id']; ?>, 'accepted')"
                                                    title="Accept Request">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <button class="btn btn-danger small-btn" 
                                                    onclick="updateRequestStatus(<?php echo $request['request_id']; ?>, 'rejected')"
                                                    title="Reject Request">
                                                <i class="fas fa-times"></i>
                                            </button>
                                            <?php elseif ($request['status'] == 'accepted'): ?>
                                            <span class="text-success small"><i class="fas fa-check-circle"></i> Accepted</span>
                                            <?php else: ?>
                                            <span class="text-danger small"><i class="fas fa-times-circle"></i> Rejected</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="mt-2">
                    <small class="text-muted">Total Requests: <?php echo $requests_result->num_rows; ?></small>
                </div>
            </div>

            <!-- Messages Tab -->
<div class="tab-pane" id="messagesTab">
    <h4 class="mb-3"><i class="fas fa-envelope text-success me-2"></i>User Messages</h4>
    
    <?php 
    // Mark all messages as read when admin views this tab
    $mark_read_stmt = $conn->prepare("UPDATE messages SET status = 'read' WHERE status = 'unread'");
    $mark_read_stmt->execute();
    $mark_read_stmt->close();
    
    // Refresh messages result after marking as read
    $messages_result = $conn->query("SELECT * FROM messages ORDER BY created_at DESC");
    
    if ($messages_result->num_rows == 0): ?>
    <div class="alert alert-info py-2">
        <i class="fas fa-info-circle"></i> No messages from users.
    </div>
    <?php else: ?>
    <div class="table-container">
        <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
            <table class="table table-hover compact-table mb-0">
                <thead>
                    <tr>
                        <th width="60">Msg ID</th>
                        <th width="80">User ID</th>
                        <th width="120">Username</th>
                        <th width="150">Email</th>
                        <th width="120">Issue Type</th>
                        <th width="200">Message</th>
                        <th width="80">Status</th>
                        <th width="90">Date</th>
                        <th width="80">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // Reset pointer for messages result
                    $messages_result->data_seek(0);
                    while ($message = $messages_result->fetch_assoc()): ?>
                    <tr>
                        <td><small>#<?php echo $message['message_id']; ?></small></td>
                        <td><small><?php echo $message['user_id']; ?></small></td>
                        <td><small><?php echo htmlspecialchars($message['username']); ?></small></td>
                        <td><small><?php echo htmlspecialchars($message['email']); ?></small></td>
                        <td><small><?php echo htmlspecialchars($message['issue_type']); ?></small></td>
                        <td><small>
                            <a href="#" data-bs-toggle="modal" data-bs-target="#messageModal<?php echo $message['message_id']; ?>">
                                <?php echo htmlspecialchars(substr($message['message'], 0, 40)) . '...'; ?>
                            </a>
                        </small></td>
                        <td>
                            <span class="badge small-badge <?php echo $message['status'] == 'read' ? 'bg-success' : 'bg-warning'; ?>">
                                <?php echo ucfirst($message['status']); ?>
                            </span>
                        </td>
                        <td><small><?php echo date('M d, Y', strtotime($message['created_at'])); ?></small></td>
                        <td>
                            <button class="btn btn-sm btn-info small-btn" data-bs-toggle="modal" data-bs-target="#messageModal<?php echo $message['message_id']; ?>" title="View Full Message">
                                <i class="fas fa-eye"></i>
                            </button>
                        </td>
                    </tr>
                    
                    <!-- Message Modal for each message -->
                    <div class="modal fade" id="messageModal<?php echo $message['message_id']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header bg-info text-white">
                                    <h5 class="modal-title"><i class="fas fa-envelope me-2"></i>Message Details</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label class="form-label"><strong>Message ID:</strong></label>
                                        <p>#<?php echo $message['message_id']; ?></p>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"><strong>User ID:</strong></label>
                                        <p><?php echo $message['user_id']; ?></p>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"><strong>Username:</strong></label>
                                        <p><?php echo htmlspecialchars($message['username']); ?></p>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"><strong>Email:</strong></label>
                                        <p><?php echo htmlspecialchars($message['email']); ?></p>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"><strong>Issue Type:</strong></label>
                                        <p><?php echo htmlspecialchars($message['issue_type']); ?></p>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"><strong>Full Message:</strong></label>
                                        <div class="border rounded p-3 bg-light">
                                            <?php echo nl2br(htmlspecialchars($message['message'])); ?>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"><strong>Date:</strong></label>
                                        <p><?php echo date('F d, Y h:i A', strtotime($message['created_at'])); ?></p>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="mt-2">
        <small class="text-muted">Total Messages: <?php echo $messages_result->num_rows; ?></small>
    </div>
    <?php endif; ?>
    
    <script>
    // Remove messages badge when messages tab is viewed
    document.addEventListener('DOMContentLoaded', function() {
        // Check if we're on the messages tab
        const messagesTab = document.getElementById('messagesTab');
        if (messagesTab && messagesTab.classList.contains('active')) {
            // Remove the badge
            const messagesBadge = document.getElementById('messagesBadge');
            if (messagesBadge) {
                messagesBadge.style.display = 'none';
            }
        }
    });
    </script>
</div>

            <!-- Statistics Tab -->
            <div class="tab-pane" id="statsTab">
                <h4 class="mb-3"><i class="fas fa-chart-bar text-success me-2"></i>System Statistics</h4>
                
                <?php
                // Re-fetch statistics for this tab
                $total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
                $active_users = $conn->query("SELECT COUNT(*) as count FROM users WHERE status = 'active'")->fetch_assoc()['count'];
                $deactivated_users = $conn->query("SELECT COUNT(*) as count FROM users WHERE status = 'deactivated'")->fetch_assoc()['count'];
                $total_requests = $conn->query("SELECT COUNT(*) as count FROM requests")->fetch_assoc()['count'];
                $pending_requests = $conn->query("SELECT COUNT(*) as count FROM requests WHERE status = 'pending'")->fetch_assoc()['count'];
                $accepted_requests = $conn->query("SELECT COUNT(*) as count FROM requests WHERE status = 'accepted'")->fetch_assoc()['count'];
                $rejected_requests = $conn->query("SELECT COUNT(*) as count FROM requests WHERE status = 'rejected'")->fetch_assoc()['count'];
                ?>
                
                <div class="row">
                    <div class="col-md-3 col-6 mb-3">
                        <div class="stat-card bg-primary text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6>Total Users</h6>
                                    <h2><?php echo $total_users; ?></h2>
                                </div>
                                <i class="fas fa-users"></i>
                            </div>
                            <small class="opacity-75">All registered users</small>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-6 mb-3">
                        <div class="stat-card bg-success text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6>Active Users</h6>
                                    <h2><?php echo $active_users; ?></h2>
                                </div>
                                <i class="fas fa-user-check"></i>
                            </div>
                            <small class="opacity-75">Currently active</small>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-6 mb-3">
                        <div class="stat-card bg-danger text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6>Inactive Users</h6>
                                    <h2><?php echo $deactivated_users; ?></h2>
                                </div>
                                <i class="fas fa-user-slash"></i>
                            </div>
                            <small class="opacity-75">Deactivated accounts</small>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-6 mb-3">
                        <div class="stat-card bg-info text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6>Total Requests</h6>
                                    <h2><?php echo $total_requests; ?></h2>
                                </div>
                                <i class="fas fa-list"></i>
                            </div>
                            <small class="opacity-75">All collection requests</small>
                        </div>
                    </div>
                    
                    <div class="col-md-4 col-6 mb-3">
                        <div class="stat-card bg-warning text-dark">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6>Pending</h6>
                                    <h2><?php echo $pending_requests; ?></h2>
                                </div>
                                <i class="fas fa-clock"></i>
                            </div>
                            <small class="opacity-75">Awaiting review</small>
                        </div>
                    </div>
                    
                    <div class="col-md-4 col-6 mb-3">
                        <div class="stat-card bg-success text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6>Accepted</h6>
                                    <h2><?php echo $accepted_requests; ?></h2>
                                </div>
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <small class="opacity-75">Approved requests</small>
                        </div>
                    </div>
                    
                    <div class="col-md-4 col-6 mb-3">
                        <div class="stat-card bg-danger text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6>Rejected</h6>
                                    <h2><?php echo $rejected_requests; ?></h2>
                                </div>
                                <i class="fas fa-times-circle"></i>
                            </div>
                            <small class="opacity-75">Declined requests</small>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Summary -->
                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="card border-light shadow-sm">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="fas fa-chart-pie me-2"></i>User Distribution</h6>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <small>Active Users</small>
                                    <small class="fw-bold"><?php echo $active_users; ?> (<?php echo $total_users > 0 ? round(($active_users/$total_users)*100) : 0; ?>%)</small>
                                </div>
                                <div class="progress mb-3" style="height: 8px;">
                                    <div class="progress-bar bg-success" style="width: <?php echo $total_users > 0 ? ($active_users/$total_users)*100 : 0; ?>%"></div>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <small>Inactive Users</small>
                                    <small class="fw-bold"><?php echo $deactivated_users; ?> (<?php echo $total_users > 0 ? round(($deactivated_users/$total_users)*100) : 0; ?>%)</small>
                                </div>
                                <div class="progress mb-3" style="height: 8px;">
                                    <div class="progress-bar bg-danger" style="width: <?php echo $total_users > 0 ? ($deactivated_users/$total_users)*100 : 0; ?>%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card border-light shadow-sm">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Request Status</h6>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <small>Pending</small>
                                    <small class="fw-bold"><?php echo $pending_requests; ?> (<?php echo $total_requests > 0 ? round(($pending_requests/$total_requests)*100) : 0; ?>%)</small>
                                </div>
                                <div class="progress mb-3" style="height: 8px;">
                                    <div class="progress-bar bg-warning" style="width: <?php echo $total_requests > 0 ? ($pending_requests/$total_requests)*100 : 0; ?>%"></div>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <small>Accepted</small>
                                    <small class="fw-bold"><?php echo $accepted_requests; ?> (<?php echo $total_requests > 0 ? round(($accepted_requests/$total_requests)*100) : 0; ?>%)</small>
                                </div>
                                <div class="progress mb-3" style="height: 8px;">
                                    <div class="progress-bar bg-success" style="width: <?php echo $total_requests > 0 ? ($accepted_requests/$total_requests)*100 : 0; ?>%"></div>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <small>Rejected</small>
                                    <small class="fw-bold"><?php echo $rejected_requests; ?> (<?php echo $total_requests > 0 ? round(($rejected_requests/$total_requests)*100) : 0; ?>%)</small>
                                </div>
                                <div class="progress mb-3" style="height: 8px;">
                                    <div class="progress-bar bg-danger" style="width: <?php echo $total_requests > 0 ? ($rejected_requests/$total_requests)*100 : 0; ?>%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Sidebar Toggle Functionality
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const adminContent = document.getElementById('adminContent');
    const adminHeader = document.getElementById('adminHeader');
    
    // Check if sidebar state is saved in localStorage
    const isSidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    
    // Initialize sidebar state
    if (isSidebarCollapsed) {
        sidebar.classList.add('collapsed');
        adminContent.classList.add('expanded');
        adminHeader.classList.add('expanded');
        sidebarToggle.innerHTML = '<i class="fas fa-bars"></i>';
        sidebarToggle.classList.add('collapsed');
    }
    
    // Toggle sidebar
    sidebarToggle.addEventListener('click', function() {
        sidebar.classList.toggle('collapsed');
        adminContent.classList.toggle('expanded');
        adminHeader.classList.toggle('expanded');
        
        // Change icon
        if (sidebar.classList.contains('collapsed')) {
            this.innerHTML = '<i class="fas fa-bars"></i>';
            this.classList.add('collapsed');
            localStorage.setItem('sidebarCollapsed', 'true');
        } else {
            this.innerHTML = '<i class="fas fa-times"></i>';
            this.classList.remove('collapsed');
            localStorage.setItem('sidebarCollapsed', 'false');
        }
    });
    
    // Tab switching functionality
    document.addEventListener('DOMContentLoaded', function() {
        const tabLinks = document.querySelectorAll('.sidebar-nav .nav-link');
        const tabPanes = document.querySelectorAll('.tab-pane');
        
        // Initialize - show first tab
        showTab('users');
        
        // Add click event to all tab links
        tabLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const tabId = this.getAttribute('data-tab');
                showTab(tabId);
                
                // Update active state
                tabLinks.forEach(l => l.classList.remove('active'));
                this.classList.add('active');
            });
        });
    });
    
    function showTab(tabId) {
        // Hide all tab panes
        const tabPanes = document.querySelectorAll('.tab-pane');
        tabPanes.forEach(pane => {
            pane.classList.remove('active');
        });
        
        // Show selected tab pane
        const activeTab = document.getElementById(tabId + 'Tab');
        if (activeTab) {
            activeTab.classList.add('active');
        }
    }
    
    function toggleUserStatus(userId, currentStatus) {
        if (confirm('Are you sure you want to ' + (currentStatus == 'active' ? 'deactivate' : 'activate') + ' user ' + userId + '?')) {
            window.location.href = '?action=toggle_user&user_id=' + userId + '&status=' + currentStatus;
        }
    }
    
    function updateRequestStatus(requestId, newStatus) {
        if (confirm('Are you sure you want to ' + newStatus + ' request #' + requestId + '?')) {
            window.location.href = '?action=update_request&request_id=' + requestId + '&status=' + newStatus;
        }
    }
    </script>
</body>
</html>
<?php
$conn->close();
?>