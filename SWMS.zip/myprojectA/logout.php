<?php
include_once 'includes/functions.php';

// Start session if not started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Clear all session variables
$_SESSION = array();

// Destroy the session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy the session
session_destroy();

// Prevent caching
header("Cache-Control: no-cache, no-store, must-revalidate"); 
header("Pragma: no-cache"); 
header("Expires: 0"); 

// Redirect to index with no-cache headers
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logging out...</title>
    <script>
        // Clear browser history and prevent back button
        history.pushState(null, null, location.href);
        history.back();
        history.forward();
        
        window.onpopstate = function () {
            history.go(1);
        };
        
        // Clear all session storage
        sessionStorage.clear();
        
        // Redirect to home page
        window.location.replace('index.php');
    </script>
</head>
<body>
    <div style="text-align: center; margin-top: 100px;">
        <h3>Logging out...</h3>
        <p>Please wait while we redirect you to the home page.</p>
        <p>If you are not redirected automatically, <a href="index.php">click here</a>.</p>
    </div>
</body>
</html>
<?php
exit();
?>