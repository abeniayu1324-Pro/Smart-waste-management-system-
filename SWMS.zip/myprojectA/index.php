<?php
include_once 'config/database.php';
include_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SWMS.FaCP</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="assets/logo.jpg">
    <style>
        .hero{
      
            background-image:url("assets/nn.jpg")
           }
           .hero p{
            color:white;
            font-size:25px;
            }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
          <a class="navbar-brand d-flex align-items-center gap-2" href="#">
    <img src="assets/logo.jpg" alt="Logo" class="brand-logo">
    <span>SWMS.FaCP</span>
          </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#features">Smart Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#how-it-works">How It Works</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#services">Our Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <button class="btn btn-outline-light ms-2" data-bs-toggle="modal" data-bs-target="#loginModal">
                            <i class="fas fa-sign-in-alt"></i> Login
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="btn btn-success ms-2" data-bs-toggle="modal" data-bs-target="#signupModal">
                            <i class="fas fa-user-plus"></i> Sign Up
                        </button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="container">
            <div class="hero-content animate-up">
                <strong><h1>Smart Waste Management System</h1></strong>
                
                <p class="lead">Revolutionizing waste collection with website for a cleaner, greener Ethiopia</p>
                <p>Join our mission to make Ethiopian cities cleaner and more sustainable through smart technology</p>
                <div class="mt-4">
                    <button class="btn btn-success btn-lg me-3" data-bs-toggle="modal" data-bs-target="#signupModal">
                        <i>Join Us</i> 
                    </button>
                    <a href="#features" class="btn btn-outline-light btn-lg">
                        <i class="fas fa-info-circle"></i> Learn More
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- our Smart Features -->
    <section id="features" class="features">
        <div class="container">
            <div class="row mb-5">
                <div class="col-lg-12 text-center animate-up">
                    <h2 class="display-5 mb-3">Our Smart Features</h2>
                    <p class="lead text-muted">Innovative solutions for modern waste management</p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 animate-left">
                    <div class="feature-card">
                        <i class="fas fa-microchip"></i>
                        <h4>IoT Enabled Bins</h4>
                        <p>Smart bins with sensors that notify when they're full and need collection.</p>
                    </div>
                </div>
                <div class="col-md-4 animate-up">
                    <div class="feature-card">
                        <i class="fas fa-map-marked-alt"></i>
                        <h4>Real-time Tracking</h4>
                        <p>Track waste collection vehicles in real-time for efficient route planning.</p>
                    </div>
                </div>
                <div class="col-md-4 animate-right">
                    <div class="feature-card">
                        <i class="fas fa-chart-line"></i>
                        <h4>Data Analytics</h4>
                        <p>Advanced analytics to optimize waste collection schedules and routes.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works -->
    <section id="how-it-works" class="how-it-works">
        <div class="container">
            <div class="row mb-5">
                <div class="col-lg-12 text-center">
                    <h2 class="display-5 mb-3">How It Works</h2>
                    <p class="lead text-muted">Simple steps to manage your waste efficiently</p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 animate-left">
                    <div class="step-card">
                        <div class="step-number">1</div>
                        <h4>Sign Up</h4>
                        <p>Create your account and get your unique User ID</p>
                    </div>
                </div>
                <div class="col-md-3 animate-up">
                    <div class="step-card">
                        <div class="step-number">2</div>
                        <h4>Create Request</h4>
                        <p>Submit waste collection requests from your dashboard</p>
                    </div>
                </div>
                <div class="col-md-3 animate-up">
                    <div class="step-card">
                        <div class="step-number">3</div>
                        <h4>Track Progress</h4>
                        <p>Monitor your request status in real-time</p>
                    </div>
                </div>
                <div class="col-md-3 animate-right">
                    <div class="step-card">
                        <div class="step-number">4</div>
                        <h4>Get Service</h4>
                        <p>Our team collects waste at scheduled time</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Services -->
    <section id="services" class="services">
        <div class="container">
            <div class="row mb-5">
                <div class="col-lg-12 text-center">
                    <h2 class="display-5 mb-3">Some of Our Services</h2>
                    <p class="lead text-muted">Comprehensive waste management solutions</p>
                </div>
            </div>
            <div class="row">
                <?php
                $services = [
                    ['icon' => 'fa-toilet', 'title' => 'Toilet Waste', 'desc' => 'Safe and hygienic toilet waste collection'],
                    ['icon' => 'fa-plastic-bottle', 'title' => 'Plastic Waste', 'desc' => 'Recycling plastic waste for better environment'],
                    ['icon' => 'fa-apple-alt', 'title' => 'Food Waste', 'desc' => 'Organic waste collection and composting'],
                    ['icon' => 'fa-trash-alt', 'title' => 'General Waste', 'desc' => 'Regular household waste collection'],
                    ['icon' => 'fa-biohazard', 'title' => 'Medical Waste', 'desc' => 'Safe disposal of medical waste'],
                    ['icon' => 'fa-recycle', 'title' => 'Recycling', 'desc' => 'Eco-friendly recycling services']
                ];
                
                foreach ($services as $index => $service) {
                    $animation = $index % 2 == 0 ? 'animate-left' : 'animate-right';
                    echo '<div class="col-md-4 mb-4 ' . $animation . '">';
                    echo '<div class="service-item">';
                    echo '<i class="fas ' . $service['icon'] . ' fa-2x mb-3 text-success"></i>';
                    echo '<h5>' . $service['title'] . '</h5>';
                    echo '<p>' . $service['desc'] . '</p>';
                    echo '</div></div>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="features">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 animate-left">
                    <h2 class="display-5 mb-4">About SmartWaste</h2>
                    <p class="lead">Transforming waste management in Ethiopia through technology</p>
                    <p>Smart Waste Management System is an innovative solution designed to address waste management challenges in Ethiopian cities. Our platform connects residents with waste collection services efficiently and sustainably.</p>
                    <div class="mt-4">
                        <div class="d-flex align-items-center mb-3">
                            <i class="fas fa-check-circle text-success me-3"></i>
                            <span>Real-time waste collection requests</span>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <i class="fas fa-check-circle text-success me-3"></i>
                            <span>Smart routing for collection vehicles</span>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <i class="fas fa-check-circle text-success me-3"></i>
                            <span>Environmental impact tracking</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 animate-right">
                    <div class="card border-0 shadow-lg">
                        <img src="assets/mm.png" 
                             class="card-img-top" alt="Smart Waste Management">
                        <div class="card-body">
                            <h5 class="card-title">Our Mission</h5>
                            <p class="card-text">To create cleaner, healthier cities in Ethiopia through innovative waste management solutions that are accessible to all residents.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5> <a class="navbar-brand d-flex align-items-center gap-2" href="#">
                   <img src="assets/logo.jpg" alt="Logo" class="brand-logo">
                  <span>SWMS.FaCP</span>
                  </a></h5>
                    <p>Smart Waste Management System for Ethiopian cities. Making our cities cleaner through technology.</p>
                </div>
                <div class="col-lg-2 mb-4">
                    <h5>Quick Links</h5>
                    <div class="footer-links">
                        <a href="#home">Home</a>
                        <a href="#features">Features</a>
                        <a href="#how-it-works">How It Works</a>
                        <a href="#services">Services</a>
                        <a href="#about">About</a>
                    </div>
                </div>
                <div class="col-lg-3 mb-4">
                    <h5>Contact Us</h5>
                    <div class="footer-links">
                        <a href="#"><i class="fas fa-phone me-2"></i> +251 011 234 567</a>
                        <a href="https://youtu.be/Mu9IRAPrbv4?si=FTBB14jbDMtK5Or6"><i class="fab fa-youtube"></i> watchvedio@youtube.com</a>
                        <a href="http://maps.google.com"><i class="fas fa-map-marker-alt me-2"></i> Addis Ababa, Ethiopia</a>
                    </div>
                </div>
                <div class="col-lg-3 mb-4">
                    <h5>Connect With Us</h5>
                    <div class="social-links">
                        <a href="https://www.facebook.com" class="btn btn-outline-light btn-sm me-2"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://www.twitter.com" class="btn btn-outline-light btn-sm me-2"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.linkedin.com" class="btn btn-outline-light btn-sm"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
            </div>
            <hr class="mt-4 mb-4">
            <div class="row">
                <div class="col-md-12 text-center">
                    <p>&copy; <?php echo date('Y'); ?> Smart Waste Management System. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Signup Modal -->
    <div class="modal fade" id="signupModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-user-plus me-2"></i>Create Account</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form id="signupForm" action="signup.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="fullname" class="form-label">Full Name *</label>
                            <input type="text" class="form-control" id="fullname" name="fullname" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email * (@gmail.com only)</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                            <small class="text-muted">Must be a valid @gmail.com address</small>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password *</label>
                            <div class="password-container">
                                <input type="password" class="form-control" id="password" name="password" required>
                                <button type="button" class="password-toggle">
                                    
                                </button>
                            </div>
                            <small class="text-muted">6-8 chars, 1 uppercase, 1 lowercase, 1 number</small>
                        </div>
                        <div class="mb-3">
                            <label for="confirmPassword" class="form-label">Confirm Password *</label>
                            <div class="password-container">
                                <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required>
                                <button type="button" class="password-toggle">
                                
                                </button>
                            </div>
                        </div>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i>
                            Your username will be: <span id="generatedUsername" class="fw-bold">FullName@swms.com</span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Create Account</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Login Modal -->
<div class="modal fade" id="loginModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-sign-in-alt me-2"></i>Login</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="loginForm" action="login.php" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="userId" class="form-label">User ID *</label>
                        <input type="text" class="form-control" id="userId" name="userId" placeholder="Enter User ID" required>
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username *</label>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Enter Username" required>
                    </div>
                    <div class="mb-3">
                        <label for="loginPassword" class="form-label">Password *</label>
                        <div class="password-container">
                            <input type="password" class="form-control" id="loginPassword" name="password" required>
                            <button type="button" class="password-toggle">
                               
                            </button>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="#" data-bs-toggle="modal" data-bs-target="#forgotModal" data-bs-dismiss="modal" class="text-decoration-none">
                            <i class="fas fa-key"></i> Forgot Password?
                        </a>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Login</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
// Function to check URL and open modal
function checkAndOpenModal() {
    const urlParams = new URLSearchParams(window.location.search);
    const showLogin = urlParams.get('showLogin');
    
    if (showLogin === 'true') {
        // Create and show the modal
        const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
        loginModal.show();
        
        // Clear the URL parameter
        const url = new URL(window.location);
        url.searchParams.delete('showLogin');
        window.history.replaceState({}, '', url);
    }
}

// Run on page load
document.addEventListener('DOMContentLoaded', checkAndOpenModal);
</script>

    
   <!-- Forgot Password Modal -->
<div class="modal fade" id="forgotModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-key me-2"></i>Forgot Password</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>You will be redirected to the identity verification page.</p>
                <p>Please provide your User ID and Email to reset your password.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <a href="forgot_password.php" class="btn btn-success">Continue</a>
            </div>
        </div>
    </div>
</div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
     <script>
// Function to check URL and open modal
function checkAndOpenModal() {
    const urlParams = new URLSearchParams(window.location.search);
    const showLogin = urlParams.get('showLogin');
    const showSignup = urlParams.get('showSignup');
    
    if (showLogin === 'true') {
        // Open login modal
        const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
        loginModal.show();
        
        // Clear the URL parameter
        const url = new URL(window.location);
        url.searchParams.delete('showLogin');
        window.history.replaceState({}, '', url);
    }
    
    if (showSignup === 'true') {
        // Open signup modal
        const signupModal = new bootstrap.Modal(document.getElementById('signupModal'));
        signupModal.show();
        
        // Clear the URL parameter
        const url = new URL(window.location);
        url.searchParams.delete('showSignup');
        window.history.replaceState({}, '', url);
    }
}

// Run on page load
document.addEventListener('DOMContentLoaded', checkAndOpenModal);

// Also check when page is shown (for back/forward navigation)
window.addEventListener('pageshow', checkAndOpenModal);
</script>
    <script src="script/script.js"></script>
</body>
</html>