<?php
// Common functions for SWMS

// Start session if not started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Check if admin is logged in
function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']);
}

// Redirect function
function redirect($url) {
    header("Location: $url");
    exit();
}

// Generate next user ID
function generateUserID() {
    global $conn;
    $sql = "SELECT MAX(CAST(user_id AS UNSIGNED)) as max_id FROM users";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $next_id = $row['max_id'] + 1;
        return str_pad($next_id, 3, '0', STR_PAD_LEFT);
    } else {
        return '001';
    }
}

// Generate username from fullname
function generateUsername($fullname) {
    $username = str_replace(' ', '', $fullname) . '@swms.com';
    return strtolower($username);
}

// Show success message
function showSuccess($message) {
    return '<div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle"></i> ' . $message . '
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>';
}

// Show error message
function showError($message) {
    return '<div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-circle"></i> ' . $message . '
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>';
}

// Get Ethiopian cities
function getEthiopianCities() {
    return [
        'Addis Ababa - Piassa',
        'Addis Ababa - Bole',
        'Addis Ababa - Mexico',
        'Addis Ababa - Lamberet',
        'Addis Ababa - Megenagna',
        'Addis Ababa - Saris',
        'Addis Ababa - Kazanchis',
        'Addis Ababa - Churchill',
        'Addis Ababa - Piazza',
        'Addis Ababa - Merkato',
        'Sebeta',
        'Adama',
        'Dire Dawa',
        'Bahir Dar',
        'Gondar',
        'Mekelle',
        'Hawassa',
        'Jimma',
        'Dessie',
        'Jijiga'
    ];
}

// Get waste types
function getWasteTypes() {
    return [
        'Toilet Waste',
        'Plastic Waste',
        'Food Waste',
        'Paper Waste',
        'Glass Waste',
        'Metal Waste',
        'Electronic Waste',
        'Medical Waste',
        'Garden Waste',
        'Construction Waste',
        'Recyclable Waste',
        'Hazardous Waste'
    ];
}
?>