<?php
session_start();
include_once 'config/database.php';
include_once 'includes/functions.php';



// Check if user came from deactivated account
if (!isset($_SESSION['deactivated_user']) && !isset($_POST['submit'])) {
    header('Location: index.php');
    exit();
}

// Handle form submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = sanitize($_POST['user_id']);
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $issue_type = sanitize($_POST['issue_type']);
    $message_text = sanitize($_POST['message']);
    
    // Insert message into database
    $stmt = $conn->prepare("INSERT INTO messages (user_id, username, email, issue_type, message) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $user_id, $username, $email, $issue_type, $message_text);
    
    if ($stmt->execute()) {
        // Clear deactivated user session
        unset($_SESSION['deactivated_user']);
        
        echo '<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Message Sent | Smart Waste Management</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
            <link rel="stylesheet" href="css/style.css">
        </head>
        <body>
            <div class="container mt-5">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="card border-success shadow-lg">
                            <div class="card-header bg-success text-white">
                                <h4><i class="fas fa-check-circle"></i> Message Sent Successfully</h4>
                            </div>
                            <div class="card-body">
                                <div class="alert alert-success">
                                    <h5><i class="fas fa-envelope"></i> Message Received!</h5>
                                    <p>Your message has been sent to the admin team.</p>
                                </div>
                                
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle"></i>
                                    <strong>What happens next:</strong>
                                    <ul class="mb-0 mt-2">
                                        <li>Admin will review your message within 24 hours</li>
                                        <li>You will receive a notification at your registered email</li>
                                        <li>Your account status will be updated accordingly</li>
                                    </ul>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <a href="index.php" class="btn btn-success">
                                        <i class="fas fa-home"></i> Back to Homepage
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>';
        exit();
    } else {
        $message = showError('Failed to send message: ' . $conn->error);
    }
    $stmt->close();
}

// Get user data from session
$user_data = $_SESSION['deactivated_user'] ?? [
    'user_id' => '',
    'username' => '',
    'email' => ''
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Admin | Smart Waste Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card border-warning shadow-lg">
                    <div class="card-header bg-warning text-white">
                        <h4><i class="fas fa-headset"></i> Contact Administrator</h4>
                    </div>
                    <div class="card-body">
                        <?php echo $message; ?>
                        
                        <div class="alert alert-danger">
                            <h5><i class="fas fa-exclamation-triangle"></i> Account Issue Detected</h5>
                            <p>Your account appears to be deactivated. Please contact the administrator for assistance.</p>
                        </div>
                        
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="user_id" class="form-label">User ID *</label>
                                <input type="text" class="form-control" id="user_id" name="user_id" 
                                       value="<?php echo $user_data['user_id']; ?>" required readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label for="username" class="form-label">Username *</label>
                                <input type="text" class="form-control" id="username" name="username" 
                                       value="<?php echo $user_data['username']; ?>" required readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email *</label>
                                <input type="email" class="form-control" id="email" name="email" 
                                       value="<?php echo $user_data['email']; ?>" required readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label for="issue_type" class="form-label">What happened? *</label>
                                <select class="form-select" id="issue_type" name="issue_type" required>
                                    <option value="">Select an issue...</option>
                                    <option value="Account deactivated">My account is deactivated</option>
                                    <option value="Cannot login">Cannot login to my account</option>
                                    <option value="Password reset">Need password reset assistance</option>
                                    <option value="Account information">Wrong account information</option>
                                    <option value="Other issue">Other issue</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="message" class="form-label">Message to Admin *</label>
                                <textarea class="form-control" id="message" name="message" rows="4" required 
                                          placeholder="Please describe your issue in detail..."></textarea>
                            </div>
                            
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i>
                                Our admin team will review your message and contact you via email.
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <a href="index.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                                <button type="submit" name="submit" class="btn btn-success">
                                    <i class="fas fa-paper-plane"></i> Send Message
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
$conn->close();
?>