<?php
if (!isset($_SESSION)) {
    session_start();
}
include_once 'config/database.php';
include_once 'includes/functions.php';

if (!isLoggedIn()) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$fullname = $_SESSION['fullname'];

// Get user stats
$stmt = $conn->prepare("SELECT 
    (SELECT COUNT(*) FROM requests WHERE user_id = ?) as total_requests,
    (SELECT COUNT(*) FROM requests WHERE user_id = ? AND status = 'pending') as pending_requests,
    (SELECT COUNT(*) FROM requests WHERE user_id = ? AND status = 'accepted') as accepted_requests");
$stmt->bind_param("sss", $user_id, $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$stats = $result->fetch_assoc();
$stmt->close();
?>
<div class="container">
    <h3 class="mb-4"><i class="fas fa-tachometer-alt text-success"></i> Dashboard</h3>
<!-- Quick Stats -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="dashboard-card text-center">
                <i class="fas fa-list fa-3x text-primary mb-3"></i>
                <h3><?php echo $stats['total_requests']; ?></h3>
                <p class="text-muted">Total Requests</p>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="dashboard-card text-center">
                <i class="fas fa-clock fa-3x text-warning mb-3"></i>
                <h3><?php echo $stats['pending_requests']; ?></h3>
                <p class="text-muted">Pending</p>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="dashboard-card text-center">
                <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                <h3><?php echo $stats['accepted_requests']; ?></h3>
                <p class="text-muted">Accepted</p>
            </div>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-bolt"></i> Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="?tab=create_request" class="btn btn-success btn-lg">
                            <i class="fas fa-plus-circle"></i> Create New Request
                        </a>
                        <a href="?tab=view_requests" class="btn btn-primary">
                            <i class="fas fa-eye"></i> View My Requests
                        </a>
                        <a href="?tab=edit_account" class="btn btn-warning">
                            <i class="fas fa-user-edit"></i> Edit Account
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="fas fa-info-circle"></i> Account Information</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <strong><i class="fas fa-id-card"></i> User ID:</strong>
                        <span class="badge bg-success"><?php echo $user_id; ?></span>
                    </div>
                    <div class="mb-3">
                        <strong><i class="fas fa-user"></i> Full Name:</strong>
                        <span><?php echo htmlspecialchars($fullname); ?></span>
                    </div>
                    <div class="mb-3">
                        <strong><i class="fas fa-envelope"></i> Email:</strong>
                        <span><?php echo htmlspecialchars($_SESSION['email']); ?></span>
                    </div>
                    <div class="mb-3">
                        <strong><i class="fas fa-calendar"></i> Member Since:</strong>
                        <span>
                            <?php
                            $stmt = $conn->prepare("SELECT created_at FROM users WHERE user_id = ?");
                            $stmt->bind_param("s", $user_id);
                            $stmt->execute();
                            $stmt->bind_result($created_at);
                            $stmt->fetch();
                            $stmt->close();
                            echo date('F d, Y', strtotime($created_at));
                            ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Requests -->
    <div class="card shadow mt-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-history"></i> Recent Requests</h5>
        </div>
        <div class="card-body">
            <?php
            $stmt = $conn->prepare("SELECT * FROM requests WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
            $stmt->bind_param("s", $user_id);
            $stmt->execute();
            $recent_requests = $stmt->get_result();
            
            if ($recent_requests->num_rows == 0) {
                echo '<div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    You haven\'t created any requests yet.
                    <a href="?tab=create_request" class="alert-link">Create your first request</a>
                </div>';
            } else {
                echo '<div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Waste Type</th>
                                <th>Address</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>';
                
                while ($request = $recent_requests->fetch_assoc()) {
                    $status_class = '';
                    switch($request['status']) {
                        case 'pending': $status_class = 'warning'; break;
                        case 'accepted': $status_class = 'success'; break;
                        case 'rejected': $status_class = 'danger'; break;
                    }
                    
                    echo '<tr>
                        <td>#' . str_pad($request['request_id'], 4, '0', STR_PAD_LEFT) . '</td>
                        <td>' . htmlspecialchars($request['waste_type']) . '</td>
                        <td>' . htmlspecialchars($request['address']) . '</td>
                        <td><span class="badge bg-' . $status_class . '">' . ucfirst($request['status']) . '</span></td>
                        <td>' . date('M d, Y', strtotime($request['created_at'])) . '</td>
                    </tr>';
                }
                
                echo '</tbody></table></div>';
                
                if ($stats['total_requests'] > 5) {
                    echo '<div class="text-center mt-3">
                        <a href="?tab=view_requests" class="btn btn-outline-primary">
                            <i class="fas fa-list"></i> View All Requests
                        </a>
                    </div>';
                }
            }
            $stmt->close();
            ?>
        </div>
    </div>
</div>