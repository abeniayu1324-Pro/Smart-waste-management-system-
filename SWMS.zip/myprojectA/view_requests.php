<?php
if (!isset($_SESSION)) {
    session_start();
}
include_once 'config/database.php';
include_once 'includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user's requests
$stmt = $conn->prepare("SELECT * FROM requests WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<div class="container">
    <h3 class="mb-4"><i class="fas fa-list text-success"></i> My Waste Collection Requests</h3>
    
    <?php
    if ($result->num_rows == 0) {
        echo '<div class="alert alert-info">
            <i class="fas fa-info-circle"></i>
            You haven\'t created any waste collection requests yet.
            <a href="?tab=create_request" class="alert-link">Create your first request</a>
        </div>';
    } else {
    ?>
    <div class="table-container">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Request ID</th>
                    <th>Waste Type</th>
                    <th>Address</th>
                    <th>Home No</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td>#<?php echo str_pad($row['request_id'], 4, '0', STR_PAD_LEFT); ?></td>
                    <td><?php echo htmlspecialchars($row['waste_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['address']); ?></td>
                    <td><?php echo htmlspecialchars($row['home_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                    <td>
                        <?php
                        $status_class = '';
                        switch($row['status']) {
                            case 'pending': $status_class = 'warning'; break;
                            case 'accepted': $status_class = 'success'; break;
                            case 'rejected': $status_class = 'danger'; break;
                        }
                        echo '<span class="badge bg-' . $status_class . '">' . ucfirst($row['status']) . '</span>';
                        ?>
                    </td>
                    <td><?php echo date('M d, Y', strtotime($row['created_at'])); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    
    <div class="alert alert-success mt-4">
        <h5><i class="fas fa-lightbulb"></i> Status Information:</h5>
        <ul class="mb-0">
            <li><span class="badge bg-warning">Pending</span> - Request received, awaiting review</li>
            <li><span class="badge bg-success">Accepted</span> - Request approved, collection scheduled we will call you and come</li>
            <li><span class="badge bg-danger">Rejected</span> - Request declined </li>
        </ul>
    </div>
    <?php
    }
    $stmt->close();
    ?>
</div>