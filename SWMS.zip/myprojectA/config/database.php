<?php
// Database configuration
$host = "localhost";
$username = "root"; 
$password = ""; 
$database = "GOD_db";

// Create connection
$conn = new mysqli($host, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS $database";
if ($conn->query($sql) === TRUE) {
    // Select database
    $conn->select_db($database);
    
    // Show success message only when directly accessed
    if (basename($_SERVER['PHP_SELF']) == 'database.php') {
        echo '<!DOCTYPE html>
        <html>
        <head>
            <title>Database Connection</title>
            <style>
                body {
                    background: #f8f9fa;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                    font-family: Arial, sans-serif;
                }
                .message-box {
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                    text-align: center;
                    border-left: 5px solid #28a745;
                }
                .success-icon {
                    color: #28a745;
                    font-size: 50px;
                    margin-bottom: 20px;
                }
                .btn {
                    background: #28a745;
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 5px;
                    cursor: pointer;
                    text-decoration: none;
                    display: inline-block;
                    margin-top: 20px;
                }
                .btn:hover {
                    background: #218838;
                }
            </style>
        </head>
        <body>
            <div class="message-box">
                <div class="success-icon">✓</div>
                <h2>Congratulations!</h2>
                <p>Database connection successful.</p>
                <p><strong>Database:</strong> ' . $database . '</p>
                <a href="index.php" class="btn">Continue to Application</a>
            </div>
        </body>
        </html>';
        exit();
    }
    
    // Import SQL file
    $sqlFile = 'export.sql';
    if (file_exists($sqlFile)) {
        $sqlScript = file_get_contents($sqlFile);
        $queries = explode(';', $sqlScript);
        
        foreach ($queries as $query) {
            if (trim($query) != '') {
                $conn->query($query);
            }
        }
    }
} else {
    die("Error creating database: " . $conn->error);
}

// Set timezone for Ethiopia
date_default_timezone_set('Africa/Addis_Ababa');

// Function to sanitize input
function sanitize($input) {
    global $conn;
    return htmlspecialchars(stripslashes(trim($input)));
}
?>