<?php
session_start();
include_once 'config/database.php';
include_once 'includes/functions.php';



// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Handle deletion
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password = $_POST['password'];
    $reason = sanitize($_POST['reason']);
    
    // Verify password
    $stmt = $conn->prepare("SELECT password FROM users WHERE user_id = ? AND username = ?");
    $stmt->bind_param("ss", $user_id, $username);
    $stmt->execute();
    $stmt->bind_result($db_password);
    $stmt->fetch();
    $stmt->close();
    
    if ($db_password !== $password) {
        $message = showError('Incorrect password! Account deletion failed.');
    } else {
        // Delete user account
        $delete_stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
        $delete_stmt->bind_param("s", $user_id);
        
        if ($delete_stmt->execute()) {
            // Destroy session
            session_destroy();
            
            // Show success message
            echo '<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Account Deleted</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
                <link rel="stylesheet" href="css/style.css">
            </head>
            <body>
                <div class="container mt-5">
                    <div class="row justify-content-center">
                        <div class="col-md-6">
                            <div class="card border-danger shadow-lg">
                                <div class="card-header bg-danger text-white">
                                    <h4><i class="fas fa-trash-alt"></i> Account Deleted</h4>
                                </div>
                                <div class="card-body">
                                    <div class="alert alert-success">
                                        <h5><i class="fas fa-check-circle"></i> Account Successfully Deleted!</h5>
                                        <p>Your account and all associated data have been permanently removed from our system.</p>
                                    </div>
                                    
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle"></i>
                                        <strong>Note:</strong> 
                                        <ul class="mb-0 mt-2">
                                            <li>Your User ID (' . $user_id . ') has been released</li>
                                            <li>All your requests have been deleted</li>
                                            <li>You can create a new account anytime</li>
                                        </ul>
                                    </div>
                                    
                                    <div class="d-grid gap-2">
                                        <a href="index.php" class="btn btn-success">
                                            <i class="fas fa-home"></i> Back to Homepage
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </body>
            </html>';
            exit();
        } else {
            $message = showError('Failed to delete account: ' . $conn->error);
        }
        $delete_stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Account | Smart Waste Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card border-danger shadow-lg">
                    <div class="card-header bg-danger text-white">
                        <h4><i class="fas fa-exclamation-triangle"></i> Delete Account</h4>
                    </div>
                    <div class="card-body">
                        <?php echo $message; ?>
                        
                        <div class="alert alert-danger">
                            <h5><i class="fas fa-exclamation-circle"></i> Warning: This action cannot be undone!</h5>
                            <p>Deleting your account will:</p>
                            <ul>
                                <li>Permanently delete your profile</li>
                                <li>Remove all your waste collection requests</li>
                                <li>Delete your account history</li>
                                <li>Release your User ID for future registrations</li>
                            </ul>
                        </div>
                        
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="user_id" class="form-label">User ID</label>
                                <input type="text" class="form-control" value="<?php echo $user_id; ?>" readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" value="<?php echo $username; ?>" readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label for="reason" class="form-label">Reason for Deleting Account</label>
                                <select class="form-select" id="reason" name="reason" required>
                                    <option value="">Select a reason...</option>
                                    <option value="No longer need service">No longer need service</option>
                                    <option value="Moving to different location">Moving to different location</option>
                                    <option value="Found better alternative">Found better alternative</option>
                                    <option value="Privacy concerns">Privacy concerns</option>
                                    <option value="Dissatisfied with service">Dissatisfied with service</option>
                                    <option value="Other">Other reason</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Enter Your Password to Confirm *</label>
                                <div class="password-container">
                                    <input type="password" class="form-control" id="password" name="password" required>
                                    <button type="button" class="password-toggle">
                                       
                                    </button>
                                </div>
                                <small class="text-muted">This is required for security verification</small>
                            </div>
                            
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle"></i>
                                <strong>Final Warning:</strong> Once you click "Delete My Account", all your data will be permanently removed!
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <a href="user_dashboard.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('ARE YOU ABSOLUTELY SURE? This cannot be undone!')">
                                    <i class="fas fa-trash-alt"></i> Delete My Account
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script/script.js"></script>
</body>
</html>